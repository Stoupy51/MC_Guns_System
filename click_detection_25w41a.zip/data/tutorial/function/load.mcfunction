scoreboard objectives add burst_cooldown dummy
scoreboard objectives add impulse_cooldown dummy