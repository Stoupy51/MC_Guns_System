
#> mgs:v5.0.0/utils/damage
#
# @executed	anchored eyes & positioned ^ ^ ^
#
# @within	mgs:v5.0.0/raycast/on_targeted_entity with storage mgs:input with
#			mgs:v5.0.0/projectile/damage_entity with storage mgs:input with
#
# @args		target (string)
#			amount (float)
#			attacker (string)
#

$damage $(target) $(amount) mgs:bullet by $(attacker)

