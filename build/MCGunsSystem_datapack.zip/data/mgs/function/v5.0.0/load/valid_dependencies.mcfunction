
#> mgs:v5.0.0/load/valid_dependencies
#
# @within	mgs:v5.0.0/load/secondary
#			mgs:v5.0.0/load/valid_dependencies 1t replace [ scheduled ]
#

# Waiting for a player to get the game version, but stop function if no player found
execute unless entity @p run schedule function mgs:v5.0.0/load/valid_dependencies 1t replace
execute unless entity @p run return 0
execute store result score #game_version mgs.data run data get entity @p DataVersion

# Check if the game version is supported
scoreboard players set #mcload_error mgs.data 0
execute unless score #game_version mgs.data matches 4669.. run scoreboard players set #mcload_error mgs.data 1

# Decode errors
execute if score #mcload_error mgs.data matches 1 run tellraw @a {"translate":"mgs.mc_guns_system_error_this_version_is_made_for_minecraft_1_21_11","color":"red"}
execute if score #dependency_error mgs.data matches 1 run tellraw @a {"translate":"mgs.mc_guns_system_error_libraries_are_missingplease_download_the_ri","color":"red"}
execute if score #dependency_error mgs.data matches 1 unless score #realistic_explosion.major load.status matches 1.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/Stoupy51/RealisticExplosionLibrary"}}, {"translate":"mgs.realisticexplosion_v1_2_0"}]
execute if score #dependency_error mgs.data matches 1 if score #realistic_explosion.major load.status matches 1 unless score #realistic_explosion.minor load.status matches 2.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/Stoupy51/RealisticExplosionLibrary"}}, {"translate":"mgs.realisticexplosion_v1_2_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.block.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_block_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.block.major load.status matches 4 unless score $bs.block.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_block_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.dump.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_dump_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.dump.major load.status matches 4 unless score $bs.dump.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_dump_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.hitbox.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_hitbox_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.hitbox.major load.status matches 4 unless score $bs.hitbox.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_hitbox_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.interaction.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_interaction_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.interaction.major load.status matches 4 unless score $bs.interaction.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_interaction_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.math.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_math_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.math.major load.status matches 4 unless score $bs.math.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_math_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.move.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_move_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.move.major load.status matches 4 unless score $bs.move.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_move_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.position.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_position_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.position.major load.status matches 4 unless score $bs.position.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_position_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.random.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_random_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.random.major load.status matches 4 unless score $bs.random.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_random_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.raycast.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_raycast_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.raycast.major load.status matches 4 unless score $bs.raycast.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_raycast_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.sidebar.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_sidebar_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.sidebar.major load.status matches 4 unless score $bs.sidebar.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_sidebar_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 unless score $bs.view.major load.status matches 4.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_view_v4_0_0"}]
execute if score #dependency_error mgs.data matches 1 if score $bs.view.major load.status matches 4 unless score $bs.view.minor load.status matches 0.. run tellraw @a [{"text":"- ","color":"gold","click_event":{"action":"open_url","url":"https://github.com/mcbookshelf/bookshelf/releases"}}, {"translate":"mgs.bookshelf_view_v4_0_0"}]

# Load MC Guns System
execute if score #game_version mgs.data matches 1.. if score #mcload_error mgs.data matches 0 if score #dependency_error mgs.data matches 0 run function mgs:v5.0.0/load/confirm_load

