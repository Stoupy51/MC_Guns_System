
#> mgs:v5.0.0/zombies/build_sidebar
#
# @within	mgs:v5.0.0/zombies/refresh_sidebar with storage mgs:temp
#
# @args		zb_sb (unknown)
#

$function #bs.sidebar:create {objective:"mgs.zb_sidebar",display_name:[{text:"🧟 ",color:"dark_green",bold:true}, {translate:"mgs.zombies"}],contents:$(zb_sb)}

