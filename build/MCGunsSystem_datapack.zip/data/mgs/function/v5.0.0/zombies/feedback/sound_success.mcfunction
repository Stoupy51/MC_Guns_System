
#> mgs:v5.0.0/zombies/feedback/sound_success
#
# @within	mgs:v5.0.0/zombies/mystery_box/collect
#			mgs:v5.0.0/zombies/wallbuys/msg_purchased
#			mgs:v5.0.0/zombies/perks/on_right_click
#

playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.8 1.25

