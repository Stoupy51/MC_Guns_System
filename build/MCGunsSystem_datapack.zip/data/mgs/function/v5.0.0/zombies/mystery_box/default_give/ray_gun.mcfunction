
#> mgs:v5.0.0/zombies/mystery_box/default_give/ray_gun
#
# @within	???
#

data modify storage mgs:temp _wb_weapon set value {weapon_id:"ray_gun",name:"ray_gun",consumable:1b,magazine_id:"element_115",mag_count:3}
scoreboard players set #wb_price mgs.data 0
function mgs:v5.0.0/zombies/wallbuys/process_purchase with storage mgs:temp _wb_weapon

