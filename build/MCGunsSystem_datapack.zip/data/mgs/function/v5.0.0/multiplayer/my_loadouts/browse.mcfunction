
#> mgs:v5.0.0/multiplayer/my_loadouts/browse
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.0.0/player/config/process
#			mgs:v5.0.0/multiplayer/custom/delete
#			mgs:v5.0.0/multiplayer/custom/toggle_visibility
#

# Initialize dialog with 3 columns: [Name/Select][👁 Toggle Vis][🗑 Delete]
data modify storage mgs:temp dialog set value {type:"minecraft:multi_action",title:{translate: "mgs.my_loadouts",color:"gold",bold:true},body:[{type:"minecraft:plain_message",contents:{translate: "mgs.manage_your_custom_loadouts",color:"gray"}}],actions:[],columns:3,after_action:"close",exit_action:{label:"Back",action:{type:"run_command",command:"/trigger mgs.player.config set 4"}}}

# Copy all loadouts for iteration
data modify storage mgs:temp _iter set from storage mgs:multiplayer custom_loadouts

# Build list recursively (filtered by owner_pid via score comparison)
execute if data storage mgs:temp _iter[0] run function mgs:v5.0.0/multiplayer/my_loadouts/build_list

# Show dialog
function mgs:v5.0.0/multiplayer/show_dialog with storage mgs:temp

