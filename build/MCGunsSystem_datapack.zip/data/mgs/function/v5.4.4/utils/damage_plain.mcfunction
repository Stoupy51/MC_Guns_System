
#> mgs:v5.4.4/utils/damage_plain
#
# @within	mgs:v5.4.4/utils/signal_and_damage_plain with storage mgs:input with
#			mgs:v5.4.4/dialog/close_then
#
# @args		target (unknown)
#			amount (unknown)
#

$damage $(target) $(amount) minecraft:explosion

