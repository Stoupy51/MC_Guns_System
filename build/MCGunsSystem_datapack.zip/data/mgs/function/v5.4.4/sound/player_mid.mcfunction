
#> mgs:v5.4.4/sound/player_mid
#
# @within	mgs:v5.4.4/dialog/close_then
#			mgs:v5.4.4/sound/check/reload_mid with storage mgs:gun all.sounds
#
# @args		playermid (unknown)
#

$playsound mgs:$(playermid) player @a[distance=0.01..16] ~ ~ ~ 0.3

