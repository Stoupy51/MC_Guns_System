
#> mgs:v5.4.4/zombies/on_hit_signal
#
# @within	#mgs:signals/damage
#			mgs:v5.4.4/dialog/close_then
#

execute unless data storage mgs:zombies game{state:"active"} run return fail
execute unless entity @s[tag=mgs.zombie_round] unless entity @s[tag=mgs.zb_jockey_rider] run return fail

# Only player kills drop power-ups.
scoreboard players operation @s mgs.zb.player_hit = #total_tick mgs.data

scoreboard players operation @n[tag=mgs.ticking] mgs.zb.points += #zb_points_hit mgs.config

execute if score @n[tag=mgs.ticking] mgs.special.double_points matches 1.. run scoreboard players operation @n[tag=mgs.ticking] mgs.zb.points += #zb_points_hit mgs.config

