
#> mgs:v5.4.4/zombies/join_game
#
# @within	mgs:v5.4.4/dialog/close_then
#			mgs:v5.4.4/players/zb_join
#			mgs:v5.4.4/lobby/zombies/second [ as @a[scores={mgs.lobby.queue=2}] ]
#

execute unless score #in_zombies_map mgs.data matches 1 run return run function mgs:v5.4.4/shared/enter_map {mode:"zombies",fn:"mgs:v5.4.4/zombies/join_game"}

# Require an active game
execute unless data storage mgs:zombies game{state:"active"} run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs","fallback":"MGS"},"] "],{"translate":"mgs.no_active_zombies_game_to_join","fallback":"No active zombies game to join!","color":"red"}]

# Prevent double-joining
execute if score @s mgs.zb.in_game matches 1 run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs","fallback":"MGS"},"] "],{"translate":"mgs.you_are_already_in_the_zombies_game","fallback":"You are already in the zombies game!","color":"red"}]

execute if score @s mgs.mp.in_game matches 1 run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs","fallback":"MGS"},"] "],{"translate":"mgs.leave_your_current_game_first","fallback":"Leave your current game first!","color":"red"}]
execute if score @s mgs.mi.in_game matches 1 run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs","fallback":"MGS"},"] "],{"translate":"mgs.leave_your_current_game_first","fallback":"Leave your current game first!","color":"red"}]

# Tag as in-game and reset stats
scoreboard players set @s mgs.zb.in_game 1
scoreboard players operation @s mgs.zb.run = #zb_run mgs.data
team join mgs.zombies @s
# The XP spend tracker is reset too, or the reset reads as points spent (see xp).
scoreboard players set @s mgs.zb.points 500
scoreboard players set @s mgs.zb.xp_pts_prev 500
scoreboard players set @s mgs.zb.xp_spent_acc 0
scoreboard players set @s mgs.zb.kills 0
scoreboard players set @s mgs.zb.downs 0
scoreboard players set @s mgs.zb.passive 0
scoreboard players set @s mgs.zb.ability 0
scoreboard players set @s mgs.zb.ability_cd 0
scoreboard players set @s mgs.zb.horde_cd 0
scoreboard players set @s mgs.mp.spectate_timer 0
scoreboard players set @s mgs.mp.death_count 0
attribute @s minecraft:max_health base reset
attribute @s minecraft:entity_interaction_range base set 5

# Setup player
gamemode adventure @s

# Reset stamina so the stamina system re-inits this player at full (it owns the hunger bar)
scoreboard players set @s mgs.stam_seen 0

# Zombies has no class selection: give the fixed starting loadout (knife + pistol), matching the start function
function mgs:v5.4.4/zombies/inventory/give_starting_loadout

scoreboard players operation @s mgs.zb.prev_kills = @s mgs.total_kills

# Teleport to spawn
function mgs:v5.4.4/zombies/respawn_tp

# Call map join script (executed as the joining player)
function mgs:v5.4.4/shared/maps/call_script_at_base {mode:"zombies",script:"join"}

# Announce
tellraw @a[scores={mgs.zb.in_game=1}] ["",["",{"text":"[","color":"dark_gray"},{"score":{"name":"@s","objective":"mgs.zb.xp_level"},"color":"gold"},{"text":"] ","color":"dark_gray"},{"selector":"@s","color":"dark_green"}],[{"text":" ","color":"dark_green"}, {"translate":"mgs.joined_the_zombies_game","fallback":"joined the zombies game!"}]]
tag @s remove mgs.zb_in_pap_room

