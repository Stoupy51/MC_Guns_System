
#> mgs:v5.4.4/zombies/start_round
#
# @within	mgs:v5.4.4/dialog/close_then
#			mgs:v5.4.4/zombies/end_prep
#			mgs:v5.4.4/zombies/game_tick
#			mgs:zombies/recover
#

execute store result score #zb_round mgs.data run data get storage mgs:zombies game.round
scoreboard players add #zb_round mgs.data 1
execute store result storage mgs:zombies game.round int 1 run scoreboard players get #zb_round mgs.data

function mgs:v5.4.4/zombies/spawns/check_rounds

# Special round: drawn like BO1 dog rounds, the first in 5..7, each next one 4..5 rounds later.
# A due round without a special spawn open and in its round bounds stays normal, and the schedule moves on as if it had been special.
execute if score #zb_round mgs.data matches 1 store result score #zb_next_special_round mgs.data run random value 5..7
# At or after, since an admin round skip can jump over the due round.
execute store result score #zb_special_due mgs.data if score #zb_round mgs.data >= #zb_next_special_round mgs.data
scoreboard players set #zb_special_round mgs.data 0
execute if score #zb_special_due mgs.data matches 1 if entity @e[type=minecraft:marker,tag=mgs.spawn_special,tag=mgs.spawn_unlocked,tag=mgs.spawn_round_ok] run scoreboard players set #zb_special_round mgs.data 1
execute if score #zb_special_due mgs.data matches 1 store result score #zb_next_special_round mgs.data run random value 4..5
execute if score #zb_special_due mgs.data matches 1 run scoreboard players operation #zb_next_special_round mgs.data += #zb_round mgs.data

# Jockey round: Zonweeb only, every 10th round from round 8, and never a special round.
scoreboard players set #zb_jockey_round mgs.data 0
scoreboard players operation #zb_jockey_mod mgs.data = #zb_round mgs.data
scoreboard players remove #zb_jockey_mod mgs.data 8
scoreboard players operation #zb_jockey_mod mgs.data %= #10 mgs.data
execute if data storage mgs:zombies game{variant:"zonweeb"} if score #zb_round mgs.data matches 8.. if score #zb_jockey_mod mgs.data matches 0 unless score #zb_special_round mgs.data matches 1 run scoreboard players set #zb_jockey_round mgs.data 1

# The round's tier, for armed enemies: rounds 1-5 give 1, 6-10 give 2, 11-15 give 3, 16+ give 4.
scoreboard players set #zb_level mgs.data 4
execute if score #zb_round mgs.data matches ..15 run scoreboard players set #zb_level mgs.data 3
execute if score #zb_round mgs.data matches ..10 run scoreboard players set #zb_level mgs.data 2
execute if score #zb_round mgs.data matches ..5 run scoreboard players set #zb_level mgs.data 1

# Clamped at 4, used by both round-size formulas.
execute store result score #zb_player_count mgs.data if entity @a[scores={mgs.zb.in_game=1},gamemode=!spectator]
execute if score #zb_player_count mgs.data matches 5.. run scoreboard players set #zb_player_count mgs.data 4

execute if score #zb_special_round mgs.data matches 0 run function mgs:v5.4.4/zombies/calc_round_count_zombies
execute if score #zb_special_round mgs.data matches 1 run function mgs:v5.4.4/zombies/calc_round_count_special

# zb_to_spawn counts down as they spawn; the power-up drop chance needs the total (see powerups/check_drop).
scoreboard players operation #zb_round_total mgs.data = #zb_to_spawn mgs.data

function mgs:v5.4.4/zombies/calc_spawn_timer

# No game-over check for 3 s.
scoreboard players set #zb_round_grace mgs.data 60
scoreboard players set #zb_nobody_ticks mgs.data 0

scoreboard players set #zb_stuck_timer mgs.data 0
scoreboard players set #zb_glow_timer mgs.data 0

# Its counter survives between matches and would trip recovery early.
scoreboard players set #zb_wd_ticks mgs.data 0

function #mgs:zombies/on_round_start

function mgs:v5.4.4/zombies/refresh_sidebar

execute if score #zb_special_round mgs.data matches 0 run tellraw @a[scores={mgs.zb.in_game=1}] ["",{"text":"","color":"dark_green","bold":true},"🧟 ",{"translate":"mgs.round_2","fallback":"Round ","color":"red"},{"score":{"name":"#zb_round","objective":"mgs.data"},"color":"gold","bold":true},[{"text":" ","color":"red"}, {"translate":"mgs.has_begun","fallback":"has begun!"}]]
execute if score #zb_special_round mgs.data matches 0 as @a[scores={mgs.zb.in_game=1}] at @s run playsound mgs:zombies/round_start_generic ambient @s ~ ~ ~ 0.3 1.0

# Special rounds have their own announcement and howl instead of the round jingle; what comes depends on the map's special spawns.
execute if score #zb_special_round mgs.data matches 1 run tellraw @a[scores={mgs.zb.in_game=1}] ["",{"text":"","color":"dark_red","bold":true},"⚠ ",{"translate":"mgs.round_2","fallback":"Round ","color":"dark_red"},{"score":{"name":"#zb_round","objective":"mgs.data"},"color":"gold","bold":true},[{"text":" ","color":"dark_red"}, {"translate":"mgs.is_a_special_round","fallback":"is a special round!"}]]
execute if score #zb_special_round mgs.data matches 1 as @a[scores={mgs.zb.in_game=1}] at @s run playsound minecraft:entity.wolf.howl ambient @s ~ ~ ~ 1.0 0.6

# +2, capped at 4.
execute as @a[scores={mgs.zb.in_game=1},gamemode=!spectator] run function mgs:v5.4.4/zombies/inventory/replenish_grenades

# Zonweeb only.
execute if data storage mgs:zombies game{variant:"zonweeb"} run function mgs:v5.4.4/zombies/perks/reduce_cooldowns
execute if data storage mgs:zombies game{variant:"zonweeb"} run function mgs:v5.4.4/zombies/perks/check_guardian

scoreboard players set #zb_drops_this_round mgs.data 0
scoreboard players set #zb_cycle_done mgs.data 0

# A fresh shuffle bag the size of one full drop cycle.
function mgs:v5.4.4/zombies/powerups/queue_refill
execute store result score #zb_cycle_len mgs.data run data get storage mgs:data _pu_queue

