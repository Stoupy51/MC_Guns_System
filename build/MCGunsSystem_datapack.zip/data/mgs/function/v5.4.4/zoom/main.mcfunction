
#> mgs:v5.4.4/zoom/main
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.4.4/player/tick
#			mgs:v5.4.4/dialog/close_then
#

# Spectators see no crosshair.
execute if entity @s[gamemode=spectator] run return run function mgs:v5.4.4/zoom/crosshair_clear

# No gun.
execute unless data storage mgs:gun all.gun run return run function mgs:v5.4.4/zoom/check_slowness

# Grenades cannot aim, but still get the movement crosshair.
execute if data storage mgs:gun all.stats.grenade_type run return run function mgs:v5.4.4/zoom/crosshair_spread

# No zoom while reloading, nor while the weapon is still being raised: the scope lens would show before the model reaches the centre.
scoreboard players set #is_sneaking mgs.data 0
execute if predicate mgs:v5.4.4/is_sneaking unless entity @s[tag=mgs.reloading] unless score @s mgs.zoom_ready > #total_tick mgs.data run scoreboard players set #is_sneaking mgs.data 1

execute if data storage mgs:gun all.stats.is_zoom if score #is_sneaking mgs.data matches 0 run return run function mgs:v5.4.4/zoom/remove

# Keyed on the score, not the item: a gun switched away from mid-aim keeps its zoom stat.
execute if score #is_sneaking mgs.data matches 1 unless score @s mgs.zoom matches 1 run return run function mgs:v5.4.4/zoom/set

## The scope overlay while aiming, the spread crosshair otherwise; the crosshair is hidden behind the scope.
execute if score @s mgs.zoom matches 1 run return run function mgs:v5.4.4/zoom/crosshair_clear
function mgs:v5.4.4/zoom/crosshair_spread

