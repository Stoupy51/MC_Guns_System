
#> mgs:v5.4.4/zoom/fx_enter_zoom_pu
#
# @within	mgs:v5.4.4/dialog/close_then
#			mgs:v5.4.4/zoom/fx_enter
#

posteffect add @s mgs:zoom_pu
scoreboard players set @s mgs.zoom_fx 4
scoreboard players reset @s mgs.zoom_fx_off

