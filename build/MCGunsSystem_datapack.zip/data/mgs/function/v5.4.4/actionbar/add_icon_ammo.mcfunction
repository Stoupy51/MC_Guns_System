
#> mgs:v5.4.4/actionbar/add_icon_ammo
#
# @within	mgs:v5.4.4/dialog/close_then
#			mgs:v5.4.4/actionbar/show
#

scoreboard players set #i mgs.data 0
execute if score #i mgs.data < #capacity mgs.data run function mgs:v5.4.4/actionbar/build_icon_loop

data modify storage mgs:temp actionbar.list append value {"text":" | ","color":"#c77e36"}
execute store result score #reserve mgs.data run scoreboard players get @s mgs.reserve_ammo
data modify storage mgs:temp actionbar.list append value {"score":{"name":"#reserve","objective":"mgs.data"}}
data modify storage mgs:temp actionbar.list append value {"text":"x ","color":"gray"}
data modify storage mgs:temp actionbar.list append value {"text":"A","font":"mgs:icons","shadow_color":[0,0,0,0],"color":"gray"}

