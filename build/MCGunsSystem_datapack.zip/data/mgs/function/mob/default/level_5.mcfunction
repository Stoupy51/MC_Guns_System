
#> mgs:mob/default/level_5
#
# @within	(public)
#
# @args		entity (unknown)
#

$execute summon $(entity) run function mgs:v5.4.0/mob/default/on_new_lv5 {entity:"$(entity)"}

