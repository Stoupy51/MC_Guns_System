
#> mgs:mob/default/level_4
#
# @within	(public)
#
# @args		entity (unknown)
#

$execute summon $(entity) run function mgs:v5.4.4/mob/default/on_new {entity:"$(entity)",level:4,active_time:72000,sleep_time:1}

