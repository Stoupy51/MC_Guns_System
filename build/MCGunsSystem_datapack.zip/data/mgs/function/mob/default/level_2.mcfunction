
#> mgs:mob/default/level_2
#
# @within	(public)
#
# @args		entity (unknown)
#

$execute summon $(entity) run function mgs:v5.4.2/mob/default/on_new {entity:"$(entity)",level:2,active_time:50,sleep_time:50}

