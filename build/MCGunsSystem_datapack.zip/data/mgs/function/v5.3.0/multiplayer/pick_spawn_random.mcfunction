
#> mgs:v5.3.0/multiplayer/pick_spawn_random
#
# @within	mgs:v5.3.0/multiplayer/pick_spawn
#

execute as @n[tag=mgs.spawn_candidate,sort=random] run function mgs:v5.3.0/shared/tp_to_spawn {mode:"multiplayer"}

tag @e[tag=mgs.spawn_candidate] remove mgs.spawn_candidate
tag @a[tag=mgs.spawn_pending] remove mgs.spawn_pending
tag @a[tag=mgs.spawn_enemy] remove mgs.spawn_enemy

