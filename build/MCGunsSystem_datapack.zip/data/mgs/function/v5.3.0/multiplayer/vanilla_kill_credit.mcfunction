
#> mgs:v5.3.0/multiplayer/vanilla_kill_credit
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.3.0/multiplayer/on_respawn
#

execute as @a[tag=mgs.temp_killer] run function #mgs:signals/on_kill

# Melee, fall and fire never go through the raycast, so no headshot; cleared so a previous bullet kill cannot leak into it.
scoreboard players set #mp_kill_headshot mgs.data 0
function mgs:v5.3.0/multiplayer/random_kill_message

