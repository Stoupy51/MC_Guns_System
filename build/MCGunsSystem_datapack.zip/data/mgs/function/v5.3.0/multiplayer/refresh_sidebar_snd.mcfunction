
#> mgs:v5.3.0/multiplayer/refresh_sidebar_snd
#
# @within	mgs:v5.3.0/dialog/close_then
#			mgs:v5.3.0/multiplayer/create_sidebar_snd
#			mgs:v5.3.0/multiplayer/gamemodes/snd/tick
#

execute if score #snd_attackers mgs.data matches 1 run data modify storage mgs:temp snd_sb.atk set value '[[" ⚔ ",{"translate":"mgs.attack","fallback":"Attack","color":"gray"}],{"translate":"mgs.red","fallback":"Red","color":"red"}]'
execute if score #snd_attackers mgs.data matches 2 run data modify storage mgs:temp snd_sb.atk set value '[[" ⚔ ",{"translate":"mgs.attack","fallback":"Attack","color":"gray"}],{"translate":"mgs.blue","fallback":"Blue","color":"blue"}]'

execute if score #snd_bomb_state mgs.data matches 0 run data modify storage mgs:temp snd_sb.bomb set value '[[" 💣 ",{"translate":"mgs.bomb_2","fallback":"Bomb","color":"gray"}],{"translate":"mgs.loose","fallback":"Loose","color":"gray"}]'
execute if score #snd_bomb_state mgs.data matches 0 if entity @a[tag=mgs.snd_carrier] run data modify storage mgs:temp snd_sb.bomb set value '[[" 💣 ",{"translate":"mgs.bomb_2","fallback":"Bomb","color":"gray"}],{"translate":"mgs.carried","fallback":"Carried","color":"gold"}]'
execute if score #snd_bomb_state mgs.data matches 2 run data modify storage mgs:temp snd_sb.bomb set value '[[" 💣 ",{"translate":"mgs.bomb_2","fallback":"Bomb","color":"gray"}],{"translate":"mgs.planted","fallback":"PLANTED","color":"red","bold":true}]'

function mgs:v5.3.0/multiplayer/build_sidebar_snd with storage mgs:temp snd_sb

