
#> mgs:v5.3.0/switch/apply_quick_swap
#
# @within	mgs:v5.3.0/dialog/close_then
#			mgs:v5.3.0/switch/on_weapon_switch
#

# cooldown x (100 - quick_swap) / 100
scoreboard players operation #reduction mgs.data = #100 mgs.data
scoreboard players operation #reduction mgs.data -= @s mgs.special.quick_swap
scoreboard players operation #cooldown mgs.data *= #reduction mgs.data
scoreboard players operation #cooldown mgs.data /= #100 mgs.data

# At least 1 tick.
execute if score #cooldown mgs.data matches ..0 run scoreboard players set #cooldown mgs.data 1

