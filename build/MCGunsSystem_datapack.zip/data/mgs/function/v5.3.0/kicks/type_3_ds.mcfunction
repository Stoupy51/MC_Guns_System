
#> mgs:v5.3.0/kicks/type_3_ds
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.3.0/kicks/apply_ds
#

execute if score #random mgs.data matches 1 run rotate @s ~-0.0845 ~-0.975
execute if score #random mgs.data matches 2 run rotate @s ~-0.039 ~-0.975
execute if score #random mgs.data matches 3 run rotate @s ~-0.0 ~-0.975
execute if score #random mgs.data matches 4 run rotate @s ~0.039 ~-0.975
execute if score #random mgs.data matches 5 run rotate @s ~0.0845 ~-0.975

