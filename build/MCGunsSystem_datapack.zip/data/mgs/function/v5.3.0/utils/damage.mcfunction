
#> mgs:v5.3.0/utils/damage
#
# @executed	at @s
#
# @within	mgs:v5.3.0/utils/signal_and_damage with storage mgs:input with
#
# @args		target (unknown)
#			amount (unknown)
#			attacker (unknown)
#

$damage $(target) $(amount) mgs:bullet by $(attacker)

