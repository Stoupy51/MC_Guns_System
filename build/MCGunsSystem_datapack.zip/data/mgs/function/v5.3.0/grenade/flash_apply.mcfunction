
#> mgs:v5.3.0/grenade/flash_apply
#
# @within	mgs:v5.3.0/dialog/close_then
#			mgs:v5.3.0/grenade/detonate_flash
#

execute store result storage mgs:temp flash.radius_float float 1 run data get entity @s data.config.grenade_effect_radius
function mgs:v5.3.0/grenade/flash_area with storage mgs:temp flash

