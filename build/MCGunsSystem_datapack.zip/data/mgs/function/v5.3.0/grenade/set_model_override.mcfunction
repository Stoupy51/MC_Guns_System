
#> mgs:v5.3.0/grenade/set_model_override
#
# @executed	anchored eyes & positioned ^ ^ ^0.5
#
# @within	mgs:v5.3.0/grenade/init with entity @s data.config
#
# @args		model_override (unknown)
#

$data modify entity @s item.components."minecraft:item_model" set value "$(model_override)"

