
#> mgs:v5.3.0/shared/load_base_coordinates
#
# @executed	as the player & at current position
#
# @within	mgs:v5.3.0/zombies/start {mode:"zombies"}
#			mgs:v5.3.0/multiplayer/start {mode:"multiplayer"}
#			mgs:v5.3.0/missions/start {mode:"missions"}
#			mgs:v5.3.0/shared/summon_oob {mode:"$(mode)"}
#			mgs:v5.3.0/multiplayer/gamemodes/dom/setup {mode:"multiplayer"}
#			mgs:v5.3.0/multiplayer/gamemodes/hp/setup {mode:"multiplayer"}
#			mgs:v5.3.0/multiplayer/gamemodes/snd/setup {mode:"multiplayer"}
#			mgs:v5.3.0/multiplayer/gamemodes/demo/setup {mode:"multiplayer"}
#
# @args		mode (string)
#

$execute store result score #gm_base_x mgs.data run data get storage mgs:$(mode) game.map.base_coordinates[0]
$execute store result score #gm_base_y mgs.data run data get storage mgs:$(mode) game.map.base_coordinates[1]
$execute store result score #gm_base_z mgs.data run data get storage mgs:$(mode) game.map.base_coordinates[2]
$scoreboard players operation #$(mode)_base_x mgs.data = #gm_base_x mgs.data
$scoreboard players operation #$(mode)_base_y mgs.data = #gm_base_y mgs.data
$scoreboard players operation #$(mode)_base_z mgs.data = #gm_base_z mgs.data

