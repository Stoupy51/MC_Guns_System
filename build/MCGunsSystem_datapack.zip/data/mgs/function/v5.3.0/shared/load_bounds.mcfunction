
#> mgs:v5.3.0/shared/load_bounds
#
# @within	mgs:v5.3.0/dialog/close_then
#			mgs:v5.3.0/zombies/start {mode:"zombies"}
#			mgs:v5.3.0/multiplayer/start {mode:"multiplayer"}
#			mgs:v5.3.0/missions/start {mode:"missions"}
#
# @args		mode (string)
#

$data modify storage mgs:temp _bnd_corners set from storage mgs:$(mode) game.map.boundaries

# Min (#bound_*1) and max (#bound_*2) start at the first corner.
execute store result score #bound_x1 mgs.data run data get storage mgs:temp _bnd_corners[0][0]
execute store result score #bound_y1 mgs.data run data get storage mgs:temp _bnd_corners[0][1]
execute store result score #bound_z1 mgs.data run data get storage mgs:temp _bnd_corners[0][2]
scoreboard players operation #bound_x2 mgs.data = #bound_x1 mgs.data
scoreboard players operation #bound_y2 mgs.data = #bound_y1 mgs.data
scoreboard players operation #bound_z2 mgs.data = #bound_z1 mgs.data

# The rest are folded into the running box.
data remove storage mgs:temp _bnd_corners[0]
execute if data storage mgs:temp _bnd_corners[0] run function mgs:v5.3.0/shared/fold_bounds
data remove storage mgs:temp _bnd_corners

# Corners are relative to the map base.
scoreboard players operation #bound_x1 mgs.data += #gm_base_x mgs.data
scoreboard players operation #bound_y1 mgs.data += #gm_base_y mgs.data
scoreboard players operation #bound_z1 mgs.data += #gm_base_z mgs.data
scoreboard players operation #bound_x2 mgs.data += #gm_base_x mgs.data
scoreboard players operation #bound_y2 mgs.data += #gm_base_y mgs.data
scoreboard players operation #bound_z2 mgs.data += #gm_base_z mgs.data
$scoreboard players operation #$(mode)_bound_x1 mgs.data = #bound_x1 mgs.data
$scoreboard players operation #$(mode)_bound_y1 mgs.data = #bound_y1 mgs.data
$scoreboard players operation #$(mode)_bound_z1 mgs.data = #bound_z1 mgs.data
$scoreboard players operation #$(mode)_bound_x2 mgs.data = #bound_x2 mgs.data
$scoreboard players operation #$(mode)_bound_y2 mgs.data = #bound_y2 mgs.data
$scoreboard players operation #$(mode)_bound_z2 mgs.data = #bound_z2 mgs.data

