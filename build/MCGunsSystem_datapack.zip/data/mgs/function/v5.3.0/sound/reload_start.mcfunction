
#> mgs:v5.3.0/sound/reload_start
#
# @within	mgs:v5.3.0/dialog/close_then
#			mgs:v5.3.0/ammo/reload with storage mgs:gun all.sounds
#
# @args		reload (unknown)
#

$playsound mgs:$(reload) player @s

