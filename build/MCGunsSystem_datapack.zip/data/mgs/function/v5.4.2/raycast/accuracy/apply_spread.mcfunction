
#> mgs:v5.4.2/raycast/accuracy/apply_spread
#
# @within	mgs:v5.4.2/dialog/close_then
#			mgs:v5.4.2/shared/calc_velocity
#			mgs:v5.4.2/raycast/main
#

# https://docs.mcbookshelf.dev/en/latest/modules/random.html#random-distributions
data modify storage mgs:input with set value {}
execute store result storage mgs:input with.min int -1 run data get storage mgs:gun accuracy
execute store result storage mgs:input with.max int 1 run data get storage mgs:gun accuracy
function #bs.random:uniform with storage mgs:input with

# Divided by 100 (https://docs.mcbookshelf.dev/en/latest/modules/position.html#add-position-and-rotation).
scoreboard players operation @s bs.rot.h = $random.uniform bs.out
function #bs.position:add_rot_h {scale: 0.01}

function #bs.random:uniform with storage mgs:input with

# Divided by 100.
scoreboard players operation @s bs.rot.v = $random.uniform bs.out
function #bs.position:add_rot_v {scale: 0.01}

