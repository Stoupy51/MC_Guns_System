
#> mgs:v5.4.2/grenade/stick_to_entity
#
# @within	mgs:v5.4.2/dialog/close_then
#			mgs:v5.4.2/grenade/on_stick
#

scoreboard players add #semtex_id mgs.data 1

scoreboard players operation @s mgs.stuck_id = #semtex_id mgs.data
execute positioned ~ ~-1 ~ run scoreboard players operation @n[type=!#mgs:ignore,distance=..2,tag=!mgs.grenade,tag=!mgs.slow_bullet,tag=!global.ignore.kill,tag=!global.ignore,nbt=!{Invulnerable:true}] mgs.stuck_id = #semtex_id mgs.data

tag @s add mgs.stuck_to_entity

