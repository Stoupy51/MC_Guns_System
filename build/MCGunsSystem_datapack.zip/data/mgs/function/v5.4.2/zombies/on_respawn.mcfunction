
#> mgs:v5.4.2/zombies/on_respawn
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.4.2/player/tick
#			mgs:v5.4.2/dialog/close_then
#

scoreboard players set @s mgs.mp.death_count 0

scoreboard players add @s mgs.zb.downs 1
scoreboard players add @s mgs.st.zb.downs 1

function mgs:v5.4.2/zombies/revive/on_down

