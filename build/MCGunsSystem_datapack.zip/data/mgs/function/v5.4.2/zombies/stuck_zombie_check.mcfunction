
#> mgs:v5.4.2/zombies/stuck_zombie_check
#
# @within	mgs:v5.4.2/dialog/close_then
#			mgs:v5.4.2/zombies/game_tick [ as @e[tag=...,limit=1,sort=random] & at @s ]
#			mgs:v5.4.2/zombies/game_tick [ as @e[tag=...,limit=2,sort=random] & at @s ]
#

# Run as a non-rising zombie_round, on 24 random ones a second, spread over the ticks. Progress resets the timer.
# Timeout: 400 ticks without moving (100 once already rescued), 300 if it moves without getting closer, less when far.

# A rider goes where its mount goes, and a teleport would pull it off.
execute on vehicle run return 0

# Distance bucket to the nearest alive player, 4 (very far) to 0 (adjacent). Height counts 3 times.
scoreboard players set #cur_dist_bucket mgs.data 4
scoreboard players set #zb_near50 mgs.data 0
execute store result score #zb_px mgs.data run data get entity @s Pos[0] 10
execute store result score #zb_py mgs.data run data get entity @s Pos[1] 10
execute store result score #zb_pz mgs.data run data get entity @s Pos[2] 10
execute as @a[scores={mgs.zb.in_game=1,mgs.zb.downed=0},gamemode=!spectator,distance=..96] run function mgs:v5.4.2/zombies/stuck_player_bucket

execute store result score #cur_x mgs.data run data get entity @s Pos[0]
execute store result score #cur_z mgs.data run data get entity @s Pos[2]

# Progress: the bucket improved, or bucket 0 with the player visible. Without the line-of-sight test a player
# above or below a floor kept the zombie "not stuck" forever. XZ movement is not progress: a zombie attacking stands still.
scoreboard players set #stuck_progress mgs.data 0
execute if score #cur_dist_bucket mgs.data < @s mgs.zb.stuck_dist run scoreboard players set #stuck_progress mgs.data 1
scoreboard players set #zb_stuck_see mgs.data 0
execute if score #cur_dist_bucket mgs.data matches 0 positioned as @p[scores={mgs.zb.in_game=1,mgs.zb.downed=0},gamemode=!spectator,distance=..16] store result score #zb_stuck_see mgs.data run function #bs.view:can_see_ata {with:{}}
execute if score #zb_stuck_see mgs.data matches 1 run scoreboard players set #stuck_progress mgs.data 1

# During a PaP-room lure, a zombie at the theatre centre is where it should be (see escort, lure mode).
execute if score #zb_lure mgs.data matches 1 if entity @e[tag=mgs.lure_center,distance=..12] run scoreboard players set #stuck_progress mgs.data 1

execute if score #stuck_progress mgs.data matches 1 run scoreboard players operation @s mgs.zb.stuck_dist = #cur_dist_bucket mgs.data
execute if score #stuck_progress mgs.data matches 1 run scoreboard players operation @s mgs.zb.stuck_x = #cur_x mgs.data
execute if score #stuck_progress mgs.data matches 1 run scoreboard players operation @s mgs.zb.stuck_z = #cur_z mgs.data
execute if score #stuck_progress mgs.data matches 1 run scoreboard players operation @s mgs.zb.stuck_ticks = #total_tick mgs.data
execute if score #stuck_progress mgs.data matches 1 run tag @s remove mgs.zb_rescued
execute if score #stuck_progress mgs.data matches 1 run return 0

# Moved: XZ differs from the snapshot at the last progress (block precision).
scoreboard players set #stuck_moved mgs.data 0
execute unless score #cur_x mgs.data = @s mgs.zb.stuck_x run scoreboard players set #stuck_moved mgs.data 1
execute unless score #cur_z mgs.data = @s mgs.zb.stuck_z run scoreboard players set #stuck_moved mgs.data 1
scoreboard players set #stuck_threshold mgs.data 400
execute if score #stuck_moved mgs.data matches 1 run scoreboard players set #stuck_threshold mgs.data 300
execute if score #stuck_moved mgs.data matches 0 if entity @s[tag=mgs.zb_rescued] run scoreboard players set #stuck_threshold mgs.data 100

# With 2 zombies left the timeout drops to 5 s, so a hard-to-reach zombie is rescued quickly.
execute if score #zb_alive mgs.data matches ..2 if score #stuck_threshold mgs.data matches 101.. run scoreboard players set #stuck_threshold mgs.data 100

# The farther from every player, the shorter the wait: 7.5 s beyond 96 blocks, 10 s beyond 64.
execute if score #cur_dist_bucket mgs.data matches 4 if score #stuck_threshold mgs.data matches 151.. run scoreboard players set #stuck_threshold mgs.data 150
execute if score #cur_dist_bucket mgs.data matches 3 if score #stuck_threshold mgs.data matches 201.. run scoreboard players set #stuck_threshold mgs.data 200

# No player within 50 blocks (height counts 3 times) and standing still since its last progress: 3 s.
execute if score #zb_near50 mgs.data matches 0 if score #stuck_moved mgs.data matches 0 if score #stuck_threshold mgs.data matches 61.. run scoreboard players set #stuck_threshold mgs.data 60

scoreboard players operation #stuck_delta mgs.data = #total_tick mgs.data
scoreboard players operation #stuck_delta mgs.data -= @s mgs.zb.stuck_ticks
execute if score #stuck_delta mgs.data >= #stuck_threshold mgs.data run function mgs:v5.4.2/zombies/on_stuck_zombie

