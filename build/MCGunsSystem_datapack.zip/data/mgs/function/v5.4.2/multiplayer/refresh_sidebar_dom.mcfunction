
#> mgs:v5.4.2/multiplayer/refresh_sidebar_dom
#
# @within	mgs:v5.4.2/dialog/close_then
#			mgs:v5.4.2/multiplayer/create_sidebar_dom
#			mgs:v5.4.2/multiplayer/gamemodes/dom/score_tick
#			mgs:v5.4.2/multiplayer/gamemodes/dom/on_kill
#

execute if score #dom_owner_a mgs.data matches 0 run data modify storage mgs:temp dom_sb.a set value '[[" ",{"text":"A","color":"gray"}],["⚪ ",{"translate":"mgs.neutral","fallback":"Neutral","color":"gray"}]]'
execute if score #dom_owner_a mgs.data matches 1 run data modify storage mgs:temp dom_sb.a set value '[[" ",{"text":"A","color":"red"}],["🔴 ",{"translate":"mgs.red","fallback":"Red","color":"red"}]]'
execute if score #dom_owner_a mgs.data matches 2 run data modify storage mgs:temp dom_sb.a set value '[[" ",{"text":"A","color":"blue"}],["🔵 ",{"translate":"mgs.blue","fallback":"Blue","color":"blue"}]]'
execute if score #dom_owner_b mgs.data matches 0 run data modify storage mgs:temp dom_sb.b set value '[[" ",{"text":"B","color":"gray"}],["⚪ ",{"translate":"mgs.neutral","fallback":"Neutral","color":"gray"}]]'
execute if score #dom_owner_b mgs.data matches 1 run data modify storage mgs:temp dom_sb.b set value '[[" ",{"text":"B","color":"red"}],["🔴 ",{"translate":"mgs.red","fallback":"Red","color":"red"}]]'
execute if score #dom_owner_b mgs.data matches 2 run data modify storage mgs:temp dom_sb.b set value '[[" ",{"text":"B","color":"blue"}],["🔵 ",{"translate":"mgs.blue","fallback":"Blue","color":"blue"}]]'
execute if score #dom_owner_c mgs.data matches 0 run data modify storage mgs:temp dom_sb.c set value '[[" ",{"text":"C","color":"gray"}],["⚪ ",{"translate":"mgs.neutral","fallback":"Neutral","color":"gray"}]]'
execute if score #dom_owner_c mgs.data matches 1 run data modify storage mgs:temp dom_sb.c set value '[[" ",{"text":"C","color":"red"}],["🔴 ",{"translate":"mgs.red","fallback":"Red","color":"red"}]]'
execute if score #dom_owner_c mgs.data matches 2 run data modify storage mgs:temp dom_sb.c set value '[[" ",{"text":"C","color":"blue"}],["🔵 ",{"translate":"mgs.blue","fallback":"Blue","color":"blue"}]]'

function mgs:v5.4.2/multiplayer/build_sidebar_dom with storage mgs:temp dom_sb

