
#> mgs:v5.4.2/multiplayer/prep_tick
#
# @within	mgs:v5.4.2/tick
#			mgs:v5.4.2/dialog/close_then
#

execute unless score #in_multiplayer_map mgs.data matches 1 run return run function mgs:v5.4.2/shared/enter_map {mode:"multiplayer",fn:"mgs:v5.4.2/multiplayer/prep_tick"}

execute as @a[scores={mgs.mp.in_game=1}] unless score @s mgs.mp.class = @s mgs.mp.prev_class unless score @s mgs.mp.class matches 0 at @s run function mgs:v5.4.2/multiplayer/apply_class
execute as @a[scores={mgs.mp.in_game=1}] run scoreboard players operation @s mgs.mp.prev_class = @s mgs.mp.class

