
#> mgs:v5.4.2/shared/tp_to_spawn
#
# @within	mgs:v5.4.2/dialog/close_then
#			mgs:v5.4.2/zombies/pick_spawn {mode:"zombies"} [ as @n[tag=mgs.spawn_candidate,sort=random] ]
#			mgs:v5.4.2/zombies/whos_who/on_down {mode:"zombies"} [ as @n[tag=mgs.spawn_candidate] ]
#			mgs:v5.4.2/zombies/revive/respawn_from_body {mode:"zombies"} [ as @n[tag=mgs.spawn_candidate] ]
#			mgs:v5.4.2/zombies/revive/respawn_at_random_spawn {mode:"zombies"} [ as @n[tag=mgs.spawn_candidate] ]
#			mgs:v5.4.2/multiplayer/pick_spawn {mode:"multiplayer"} [ as @e[tag=mgs.spawn_candidate,sort=random] ]
#			mgs:v5.4.2/multiplayer/pick_spawn_random {mode:"multiplayer"} [ as @n[tag=mgs.spawn_candidate,sort=random] ]
#			mgs:v5.4.2/missions/pick_spawn {mode:"missions"} [ as @n[tag=mgs.spawn_candidate,sort=random] ]
#
# @args		mode (string)
#

# For the teleport macro.
execute store result storage mgs:temp _tp.x double 1 run data get entity @s Pos[0]
execute store result storage mgs:temp _tp.y double 1 run data get entity @s Pos[1]
execute store result storage mgs:temp _tp.z double 1 run data get entity @s Pos[2]
data modify storage mgs:temp _tp.yaw set from entity @s data.yaw

execute as @p[tag=mgs.spawn_pending] run function mgs:v5.4.2/shared/tp_player_at with storage mgs:temp _tp

# Only during prep: the spawn is used, so no two players get it.
$execute unless data storage mgs:$(mode) game{state:"active"} run tag @s add mgs.spawn_used

