
#> mgs:v5.4.2/player/flash_clear
#
# @within	mgs:v5.4.2/dialog/close_then
#			mgs:v5.4.2/player/apply_flash
#			mgs:v5.4.2/player/apply_pap_flash
#			mgs:v5.4.2/player/flash_tick
#

execute if score @s mgs.flash_id matches 1 run posteffect remove @s mgs:flash_0
execute if score @s mgs.flash_id matches 2 run posteffect remove @s mgs:flash_1
execute if score @s mgs.flash_id matches 3 run posteffect remove @s mgs:flash_zoom_0
execute if score @s mgs.flash_id matches 4 run posteffect remove @s mgs:flash_zoom_1
execute if score @s mgs.flash_id matches 5 run posteffect remove @s mgs:flash_pap_0
execute if score @s mgs.flash_id matches 6 run posteffect remove @s mgs:flash_pap_1
execute if score @s mgs.flash_id matches 7 run posteffect remove @s mgs:flash_pap_zoom_0
execute if score @s mgs.flash_id matches 8 run posteffect remove @s mgs:flash_pap_zoom_1
scoreboard players set @s mgs.flash_id 0

