
#> mgs:v5.0.1/multiplayer/bounds_kill
#
# @executed	at @s
#
# @within	mgs:v5.0.1/multiplayer/check_bounds
#			mgs:v5.0.1/multiplayer/enforce_bounds
#

# Clear attacker input (environmental death) and simulate death
data modify storage mgs:input with set value {}
function mgs:v5.0.1/multiplayer/simulate_death

