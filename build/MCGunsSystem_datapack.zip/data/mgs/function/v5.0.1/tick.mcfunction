
#> mgs:v5.0.1/tick
#
# @within	mgs:v5.0.1/load/tick_verification
#

# Infinitely incrementing tick counter for general timing purposes
scoreboard players add #total_tick mgs.data 1

# Player loop
execute as @e[type=player,sort=random] at @s run function mgs:v5.0.1/player/tick

# Tick function for slow bullets (projectiles)
execute if score #slow_bullet_count mgs.data matches 1.. as @e[tag=mgs.slow_bullet] at @s run function mgs:v5.0.1/projectile/tick

# Tick function for active grenades
execute if score #grenade_count mgs.data matches 1.. as @e[tag=mgs.grenade] at @s run function mgs:v5.0.1/grenade/tick

# Armed mob AI loop
execute if score #armed_mob_count mgs.data matches 1.. as @e[tag=mgs.armed] at @s run function mgs:v5.0.1/mob/tick

# Zombies game tick
execute if data storage mgs:zombies game{state:"active"} run function mgs:v5.0.1/zombies/game_tick
execute if data storage mgs:zombies game{state:"preparing"} run function mgs:v5.0.1/zombies/prep_tick

# Multiplayer game tick
execute if data storage mgs:multiplayer game{state:"active"} run function mgs:v5.0.1/multiplayer/game_tick
execute if data storage mgs:multiplayer game{state:"preparing"} run function mgs:v5.0.1/multiplayer/prep_tick

# Missions game tick
execute if data storage mgs:missions game{state:"active"} run function mgs:v5.0.1/missions/game_tick
execute if data storage mgs:missions game{state:"preparing"} run function mgs:v5.0.1/missions/prep_tick

