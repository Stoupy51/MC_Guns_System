
#> mgs:v5.0.1/zombies/feedback/sound_deny
#
# @executed	at @s
#
# @within	mgs:v5.0.1/maps/zombies/kino_der_toten/teleporter/deny_recharging [ at @s ]
#			mgs:v5.0.1/zombies/mystery_box/deny_moving
#			mgs:v5.0.1/zombies/mystery_box/deny_already_in_use
#			mgs:v5.0.1/zombies/mystery_box/deny_not_enough_points
#			mgs:v5.0.1/zombies/mystery_box/deny_not_your_result
#			mgs:v5.0.1/zombies/mystery_box/deny_all_owned
#			mgs:v5.0.1/zombies/pap/deny_requires_power
#			mgs:v5.0.1/zombies/pap/deny_not_enough_points
#			mgs:v5.0.1/zombies/pap/deny_hold_weapon_slot
#			mgs:v5.0.1/zombies/pap/deny_not_gun
#			mgs:v5.0.1/zombies/pap/deny_not_supported
#			mgs:v5.0.1/zombies/pap/deny_max_level
#			mgs:v5.0.1/zombies/pap/deny_not_enough_points_scope
#			mgs:v5.0.1/zombies/pap/anim/deny_not_your_weapon
#			mgs:v5.0.1/zombies/pap/anim/deny_processing
#			mgs:v5.0.1/zombies/power/deny_already_on
#			mgs:v5.0.1/zombies/doors/deny_not_enough_points
#			mgs:v5.0.1/zombies/wallbuys/deny_not_enough_points
#			mgs:v5.0.1/zombies/wallbuys/msg_refund_full
#			mgs:v5.0.1/zombies/wallbuys/deny_hold_valid_slot
#			mgs:v5.0.1/zombies/perks/deny_requires_power
#			mgs:v5.0.1/zombies/perks/deny_already_owned
#			mgs:v5.0.1/zombies/perks/deny_not_enough_points
#			mgs:v5.0.1/zombies/traps/deny_requires_power
#			mgs:v5.0.1/zombies/traps/deny_not_ready
#			mgs:v5.0.1/zombies/traps/deny_not_enough_points
#

playsound minecraft:entity.villager.no ambient @s ~ ~ ~ 0.8 1.0

