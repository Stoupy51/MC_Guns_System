
#> mgs:v5.0.1/zombies/mystery_box/default_give/mosin
#
# @within	???
#

data modify storage mgs:temp _wb_weapon set value {weapon_id:"mosin",name:"mosin",consumable:1b,magazine_id:"mosin_bullet",mag_count:10}
scoreboard players set #wb_price mgs.data 0
function mgs:v5.0.1/zombies/wallbuys/process_purchase with storage mgs:temp _wb_weapon

