
#> mgs:v5.0.1/zombies/mystery_box/default_give/famas
#
# @within	???
#

data modify storage mgs:temp _wb_weapon set value {weapon_id:"famas",name:"famas",consumable:0b,magazine_id:"famas_mag",mag_count:3}
scoreboard players set #wb_price mgs.data 0
function mgs:v5.0.1/zombies/wallbuys/process_purchase with storage mgs:temp _wb_weapon

