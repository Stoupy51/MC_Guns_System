
#> mgs:v5.0.1/zombies/mystery_box/default_give/ak47
#
# @within	???
#

data modify storage mgs:temp _wb_weapon set value {weapon_id:"ak47",name:"ak47",consumable:0b,magazine_id:"ak47_mag",mag_count:3}
scoreboard players set #wb_price mgs.data 0
function mgs:v5.0.1/zombies/wallbuys/process_purchase with storage mgs:temp _wb_weapon

