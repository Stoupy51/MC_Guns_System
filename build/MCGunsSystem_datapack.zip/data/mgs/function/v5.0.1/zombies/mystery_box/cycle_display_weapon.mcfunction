
#> mgs:v5.0.1/zombies/mystery_box/cycle_display_weapon
#
# @within	mgs:v5.0.1/zombies/mystery_box/cycle_display with storage mgs:temp _mb_cycle_item
#
# @args		weapon_id (unknown)
#

$loot replace entity @n[tag=mgs.mb_display] contents loot mgs:i/$(weapon_id)

