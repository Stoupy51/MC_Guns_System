
#> mgs:v5.4.1/shared/forceload_add
#
# @within	mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/shared/forceload_area with storage mgs:temp _fl
#
# @args		x1 (unknown)
#			z1 (unknown)
#			x2 (unknown)
#			z2 (unknown)
#

$forceload add $(x1) $(z1) $(x2) $(z2)

