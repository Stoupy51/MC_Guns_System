
#> mgs:v5.4.1/sound/compute_acoustics
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.4.1/player/tick
#			mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/sound/turret_fire
#

scoreboard players set #acoustics mgs.data 0

execute if block ~ ~1 ~ #mgs:v5.4.1/outside if block ~ ~2 ~ #mgs:v5.4.1/outside if block ~ ~3 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 8
execute if block ~ ~4 ~ #mgs:v5.4.1/outside if block ~ ~5 ~ #mgs:v5.4.1/outside if block ~ ~6 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 8
execute if block ~1 ~1 ~ #mgs:v5.4.1/outside if block ~2 ~1 ~ #mgs:v5.4.1/outside if block ~3 ~1 ~ #mgs:v5.4.1/outside if block ~1 ~2 ~ #mgs:v5.4.1/outside if block ~2 ~2 ~ #mgs:v5.4.1/outside if block ~3 ~2 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-1 ~1 ~ #mgs:v5.4.1/outside if block ~-2 ~1 ~ #mgs:v5.4.1/outside if block ~-3 ~1 ~ #mgs:v5.4.1/outside if block ~-1 ~2 ~ #mgs:v5.4.1/outside if block ~-2 ~2 ~ #mgs:v5.4.1/outside if block ~-3 ~2 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~ ~1 ~1 #mgs:v5.4.1/outside if block ~ ~1 ~2 #mgs:v5.4.1/outside if block ~ ~1 ~3 #mgs:v5.4.1/outside if block ~ ~2 ~1 #mgs:v5.4.1/outside if block ~ ~2 ~2 #mgs:v5.4.1/outside if block ~ ~2 ~3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~ ~1 ~-1 #mgs:v5.4.1/outside if block ~ ~1 ~-2 #mgs:v5.4.1/outside if block ~ ~1 ~-3 #mgs:v5.4.1/outside if block ~ ~2 ~-1 #mgs:v5.4.1/outside if block ~ ~2 ~-2 #mgs:v5.4.1/outside if block ~ ~2 ~-3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~1 ~1 #mgs:v5.4.1/outside if block ~2 ~1 ~2 #mgs:v5.4.1/outside if block ~3 ~1 ~3 #mgs:v5.4.1/outside if block ~1 ~2 ~1 #mgs:v5.4.1/outside if block ~2 ~2 ~2 #mgs:v5.4.1/outside if block ~3 ~2 ~3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-1 ~1 ~1 #mgs:v5.4.1/outside if block ~-2 ~1 ~2 #mgs:v5.4.1/outside if block ~-3 ~1 ~3 #mgs:v5.4.1/outside if block ~-1 ~2 ~1 #mgs:v5.4.1/outside if block ~-2 ~2 ~2 #mgs:v5.4.1/outside if block ~-3 ~2 ~3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~1 ~-1 #mgs:v5.4.1/outside if block ~2 ~1 ~-2 #mgs:v5.4.1/outside if block ~3 ~1 ~-3 #mgs:v5.4.1/outside if block ~1 ~2 ~-1 #mgs:v5.4.1/outside if block ~2 ~2 ~-2 #mgs:v5.4.1/outside if block ~3 ~2 ~-3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-1 ~1 ~-1 #mgs:v5.4.1/outside if block ~-2 ~1 ~-2 #mgs:v5.4.1/outside if block ~-3 ~1 ~-3 #mgs:v5.4.1/outside if block ~-1 ~2 ~-1 #mgs:v5.4.1/outside if block ~-2 ~2 ~-2 #mgs:v5.4.1/outside if block ~-3 ~2 ~-3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~3 ~ #mgs:v5.4.1/outside if block ~2 ~3 ~ #mgs:v5.4.1/outside if block ~3 ~3 ~ #mgs:v5.4.1/outside if block ~1 ~4 ~ #mgs:v5.4.1/outside if block ~2 ~4 ~ #mgs:v5.4.1/outside if block ~3 ~4 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-1 ~3 ~ #mgs:v5.4.1/outside if block ~-2 ~3 ~ #mgs:v5.4.1/outside if block ~-3 ~3 ~ #mgs:v5.4.1/outside if block ~-1 ~4 ~ #mgs:v5.4.1/outside if block ~-2 ~4 ~ #mgs:v5.4.1/outside if block ~-3 ~4 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~ ~3 ~1 #mgs:v5.4.1/outside if block ~ ~3 ~2 #mgs:v5.4.1/outside if block ~ ~3 ~3 #mgs:v5.4.1/outside if block ~ ~4 ~1 #mgs:v5.4.1/outside if block ~ ~4 ~2 #mgs:v5.4.1/outside if block ~ ~4 ~3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~ ~3 ~-1 #mgs:v5.4.1/outside if block ~ ~3 ~-2 #mgs:v5.4.1/outside if block ~ ~3 ~-3 #mgs:v5.4.1/outside if block ~ ~4 ~-1 #mgs:v5.4.1/outside if block ~ ~4 ~-2 #mgs:v5.4.1/outside if block ~ ~4 ~-3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~3 ~1 #mgs:v5.4.1/outside if block ~2 ~3 ~2 #mgs:v5.4.1/outside if block ~3 ~3 ~3 #mgs:v5.4.1/outside if block ~1 ~4 ~1 #mgs:v5.4.1/outside if block ~2 ~4 ~2 #mgs:v5.4.1/outside if block ~3 ~4 ~3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-1 ~3 ~1 #mgs:v5.4.1/outside if block ~-2 ~3 ~2 #mgs:v5.4.1/outside if block ~-3 ~3 ~3 #mgs:v5.4.1/outside if block ~-1 ~4 ~1 #mgs:v5.4.1/outside if block ~-2 ~4 ~2 #mgs:v5.4.1/outside if block ~-3 ~4 ~3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~3 ~-1 #mgs:v5.4.1/outside if block ~2 ~3 ~-2 #mgs:v5.4.1/outside if block ~3 ~3 ~-3 #mgs:v5.4.1/outside if block ~1 ~4 ~-1 #mgs:v5.4.1/outside if block ~2 ~4 ~-2 #mgs:v5.4.1/outside if block ~3 ~4 ~-3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-1 ~3 ~-1 #mgs:v5.4.1/outside if block ~-2 ~3 ~-2 #mgs:v5.4.1/outside if block ~-3 ~3 ~-3 #mgs:v5.4.1/outside if block ~-1 ~4 ~-1 #mgs:v5.4.1/outside if block ~-2 ~4 ~-2 #mgs:v5.4.1/outside if block ~-3 ~4 ~-3 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~5 ~ #mgs:v5.4.1/outside if block ~2 ~5 ~ #mgs:v5.4.1/outside if block ~1 ~6 ~ #mgs:v5.4.1/outside if block ~2 ~6 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~-1 ~5 ~ #mgs:v5.4.1/outside if block ~-2 ~5 ~ #mgs:v5.4.1/outside if block ~-1 ~6 ~ #mgs:v5.4.1/outside if block ~-2 ~6 ~ #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~ ~5 ~1 #mgs:v5.4.1/outside if block ~ ~5 ~2 #mgs:v5.4.1/outside if block ~ ~6 ~1 #mgs:v5.4.1/outside if block ~ ~6 ~2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~ ~5 ~-1 #mgs:v5.4.1/outside if block ~ ~5 ~-2 #mgs:v5.4.1/outside if block ~ ~6 ~-1 #mgs:v5.4.1/outside if block ~ ~6 ~-2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~1 ~5 ~1 #mgs:v5.4.1/outside if block ~2 ~5 ~2 #mgs:v5.4.1/outside if block ~1 ~6 ~1 #mgs:v5.4.1/outside if block ~2 ~6 ~2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~-1 ~5 ~1 #mgs:v5.4.1/outside if block ~-2 ~5 ~2 #mgs:v5.4.1/outside if block ~-1 ~6 ~1 #mgs:v5.4.1/outside if block ~-2 ~6 ~2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~1 ~5 ~-1 #mgs:v5.4.1/outside if block ~2 ~5 ~-2 #mgs:v5.4.1/outside if block ~1 ~6 ~-1 #mgs:v5.4.1/outside if block ~2 ~6 ~-2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~-1 ~5 ~-1 #mgs:v5.4.1/outside if block ~-2 ~5 ~-2 #mgs:v5.4.1/outside if block ~-1 ~6 ~-1 #mgs:v5.4.1/outside if block ~-2 ~6 ~-2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~2 ~1 ~1 #mgs:v5.4.1/outside if block ~2 ~2 ~1 #mgs:v5.4.1/outside if block ~2 ~1 ~-1 #mgs:v5.4.1/outside if block ~2 ~2 ~-1 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~-2 ~1 ~1 #mgs:v5.4.1/outside if block ~-2 ~2 ~1 #mgs:v5.4.1/outside if block ~-2 ~1 ~-1 #mgs:v5.4.1/outside if block ~-2 ~2 ~-1 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~1 ~2 #mgs:v5.4.1/outside if block ~1 ~2 ~2 #mgs:v5.4.1/outside if block ~-1 ~1 ~2 #mgs:v5.4.1/outside if block ~-1 ~2 ~2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~1 ~1 ~-2 #mgs:v5.4.1/outside if block ~1 ~2 ~-2 #mgs:v5.4.1/outside if block ~-1 ~1 ~-2 #mgs:v5.4.1/outside if block ~-1 ~2 ~-2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 4
execute if block ~2 ~3 ~1 #mgs:v5.4.1/outside if block ~2 ~4 ~1 #mgs:v5.4.1/outside if block ~2 ~3 ~-1 #mgs:v5.4.1/outside if block ~2 ~4 ~-1 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~-2 ~3 ~1 #mgs:v5.4.1/outside if block ~-2 ~4 ~1 #mgs:v5.4.1/outside if block ~-2 ~3 ~-1 #mgs:v5.4.1/outside if block ~-2 ~4 ~-1 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~1 ~3 ~2 #mgs:v5.4.1/outside if block ~1 ~4 ~2 #mgs:v5.4.1/outside if block ~-1 ~3 ~2 #mgs:v5.4.1/outside if block ~-1 ~4 ~2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~1 ~3 ~-2 #mgs:v5.4.1/outside if block ~1 ~4 ~-2 #mgs:v5.4.1/outside if block ~-1 ~3 ~-2 #mgs:v5.4.1/outside if block ~-1 ~4 ~-2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 6
execute if block ~2 ~5 ~1 #mgs:v5.4.1/outside if block ~2 ~6 ~1 #mgs:v5.4.1/outside if block ~2 ~5 ~-1 #mgs:v5.4.1/outside if block ~2 ~6 ~-1 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 8
execute if block ~-2 ~5 ~1 #mgs:v5.4.1/outside if block ~-2 ~6 ~1 #mgs:v5.4.1/outside if block ~-2 ~5 ~-1 #mgs:v5.4.1/outside if block ~-2 ~6 ~-1 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 8
execute if block ~1 ~5 ~2 #mgs:v5.4.1/outside if block ~1 ~6 ~2 #mgs:v5.4.1/outside if block ~-1 ~5 ~2 #mgs:v5.4.1/outside if block ~-1 ~6 ~2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 8
execute if block ~1 ~5 ~-2 #mgs:v5.4.1/outside if block ~1 ~6 ~-2 #mgs:v5.4.1/outside if block ~-1 ~5 ~-2 #mgs:v5.4.1/outside if block ~-1 ~6 ~-2 #mgs:v5.4.1/outside run scoreboard players add #acoustics mgs.data 8

# Score to acoustics level.
scoreboard players set @s mgs.acoustics_level 0
execute if score #acoustics mgs.data matches 121..155 run scoreboard players set @s mgs.acoustics_level 1
execute if score #acoustics mgs.data matches 86..120 run scoreboard players set @s mgs.acoustics_level 2
execute if score #acoustics mgs.data matches 51..85 run scoreboard players set @s mgs.acoustics_level 3
execute if score #acoustics mgs.data matches ..50 run scoreboard players set @s mgs.acoustics_level 4
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ #mgs:v5.4.1/sounds/water run scoreboard players set @s mgs.acoustics_level 5

