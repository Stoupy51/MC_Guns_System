
#> mgs:v5.4.1/multiplayer/apply_slot_loot
#
# @within	mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/multiplayer/apply_next_slot with storage mgs:temp current_slot
#
# @args		slot (unknown)
#			loot (unknown)
#

$loot replace entity @s $(slot) loot $(loot)

