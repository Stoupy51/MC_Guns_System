
#> mgs:v5.4.1/multiplayer/build_class_btn
#
# @within	mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/multiplayer/build_class_btn with storage mgs:temp class_iter[0]
#			mgs:v5.4.1/multiplayer/select_class with storage mgs:temp class_iter[0]
#
# @args		name (unknown)
#			lore (unknown)
#			main_gun (unknown)
#			main_mag_count (unknown)
#			secondary_gun (unknown)
#			secondary_mag_count (unknown)
#			equip_display (unknown)
#			perks_display (unknown)
#			trigger_value (unknown)
#

$data modify storage mgs:temp _btn set value {label:{text:"$(name)",color:"green"},tooltip:["",{text:"$(lore)","color":"gray"},{"text":"\n"},{"translate":"mgs.primary","fallback":"Primary"},": ",{"text":"$(main_gun)","color":"green"},{"text":" x$(main_mag_count) mags","color":"dark_green"},{"text":"\n"},["",{"translate":"mgs.secondary","fallback":"Secondary"},": "],{"text":"$(secondary_gun)","color":"yellow"},{"text":" x$(secondary_mag_count) mags","color":"gold"},{"text":"\n"},["",{"translate":"mgs.grenades","fallback":"Grenades"},": "],{"text":"$(equip_display)","color":"aqua"},{"text":"\n"},["",{"translate":"mgs.perks","fallback":"Perks"},": "],{"text":"$(perks_display)","color":"light_purple"},"\n\n",[{"text":"▶ ","color":"dark_gray","italic":true}, {"translate":"mgs.click_to_select","fallback":"Click to select"}]],action:{type:"run_command",command:"/trigger mgs.player.config set $(trigger_value)"}}

data modify storage mgs:temp dialog.actions append from storage mgs:temp _btn

data remove storage mgs:temp class_iter[0]
execute if data storage mgs:temp class_iter[0] run function mgs:v5.4.1/multiplayer/build_class_btn with storage mgs:temp class_iter[0]

