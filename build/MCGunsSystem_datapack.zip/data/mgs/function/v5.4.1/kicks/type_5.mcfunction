
#> mgs:v5.4.1/kicks/type_5
#
# @within	mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/kicks/apply
#

execute if score @s mgs.kick_dir matches 1 run rotate @s ~-0.17 ~-2.5
execute if score @s mgs.kick_dir matches 2 run rotate @s ~-0.06 ~-2.5
execute if score @s mgs.kick_dir matches 3 run rotate @s ~-0.0 ~-2.5
execute if score @s mgs.kick_dir matches 4 run rotate @s ~0.06 ~-2.5
execute if score @s mgs.kick_dir matches 5 run rotate @s ~0.17 ~-2.5

