
#> mgs:v5.4.1/raycast/apply_damage
#
# @within	mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/raycast/headshot_and_damage [ at @s ]
#

execute as @n[tag=mgs.ticking] if score @s mgs.special.instant_kill matches 1.. as @s[tag=!mgs.no_instant_kill] run scoreboard players set #damage mgs.data 99999

execute if score #is_headshot mgs.data matches 1 run data modify storage mgs:signals on_headshot set value {}
execute if score #is_headshot mgs.data matches 1 run data modify storage mgs:signals on_headshot.weapon set from storage mgs:gun all
execute if score #is_headshot mgs.data matches 1 store result storage mgs:signals on_headshot.damage float 0.1 run scoreboard players get #damage mgs.data
execute if score #is_headshot mgs.data matches 1 run function #mgs:signals/on_headshot

execute store result storage mgs:input with.amount float 0.1 run scoreboard players get #damage mgs.data
data modify storage mgs:input with.weapon set from storage mgs:gun all
execute store result storage mgs:input with.headshot int 1 run scoreboard players get #is_headshot mgs.data
function mgs:v5.4.1/utils/signal_and_damage

# Guarded against firing twice on an already dying entity.
scoreboard players set #victim_hp mgs.data 0
execute store result score #victim_hp mgs.data run data get entity @s Health 100
scoreboard players set #is_new_kill mgs.data 0
execute if score #victim_hp mgs.data matches ..0 unless entity @s[tag=mgs.already_killed] run scoreboard players set #is_new_kill mgs.data 1
execute if score #victim_hp mgs.data matches ..0 unless entity @s[tag=mgs.already_killed] run tag @s add mgs.already_killed

# The killing shot drops a mission enemy's gun while it still holds it; drop_enemy_weapon tags the mob, so the death watch cannot drop twice.
execute if score #is_new_kill mgs.data matches 1 if entity @s[tag=mgs.mission_enemy] at @s run function mgs:v5.4.1/missions/drop_enemy_weapon

execute if score #is_new_kill mgs.data matches 1 run data modify storage mgs:signals on_kill set value {}
execute if score #is_new_kill mgs.data matches 1 run data modify storage mgs:signals on_kill.weapon set from storage mgs:gun all

# The headshot goes in the payload: the projectile path fires on_kill without resetting #is_headshot.
# Absent means "not a headshot", as that path's `on_kill set value {}` gives.
execute if score #is_new_kill mgs.data matches 1 store result storage mgs:signals on_kill.headshot int 1 run scoreboard players get #is_headshot mgs.data

execute if score #is_new_kill mgs.data matches 1 as @n[tag=mgs.ticking] run function #mgs:signals/on_kill

