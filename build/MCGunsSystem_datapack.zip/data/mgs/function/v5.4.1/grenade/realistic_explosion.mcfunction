
#> mgs:v5.4.1/grenade/realistic_explosion
#
# @within	mgs:v5.4.1/dialog/close_then
#			mgs:v5.4.1/grenade/detonate_frag
#

scoreboard players operation #explosion_power realistic_explosion.data = #grenade_explosion_power mgs.config
execute if score #grenade_explosion_power mgs.config matches 1.. run scoreboard players set #falling_fire realistic_explosion.data 1
execute unless score #grenade_explosion_power mgs.config matches 1.. run scoreboard players set #falling_fire realistic_explosion.data 0
function realistic_explosion:explode

