
#> mgs:v5.4.3/ammo/found_lore_line
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/ammo/search_lore_loop with storage mgs:input with
#
# @args		slot (unknown)
#			index (unknown)
#			capacity (unknown)
#			remaining_bullets (unknown)
#

$item replace entity @s contents from entity @p[tag=mgs.modify_lore] $(slot)

$data modify entity @s item.components."minecraft:lore"[$(index)].extra[-1] set value "$(capacity)"
$data modify entity @s item.components."minecraft:lore"[$(index)].extra[-3] set value "$(remaining_bullets)"

$item replace entity @p[tag=mgs.modify_lore] $(slot) from entity @s contents

kill @s

