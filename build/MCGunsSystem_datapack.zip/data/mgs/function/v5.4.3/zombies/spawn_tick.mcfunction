
#> mgs:v5.4.3/zombies/spawn_tick
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zombies/game_tick
#

scoreboard players remove #zb_spawn_timer mgs.data 1
execute if score #zb_spawn_timer mgs.data matches 1.. run return 0

function mgs:v5.4.3/zombies/calc_spawn_timer

scoreboard players operation #zb_spawn_batch_remaining mgs.data = #zb_spawn_batch mgs.data
function mgs:v5.4.3/zombies/spawn_batch_tick

