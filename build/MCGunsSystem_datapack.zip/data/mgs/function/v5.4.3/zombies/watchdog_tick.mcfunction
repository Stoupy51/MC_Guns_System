
#> mgs:v5.4.3/zombies/watchdog_tick
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zombies/game_tick
#

# Any spawn, kill or portal strike moves it.
scoreboard players operation #zb_wd_fp mgs.data = #zb_alive mgs.data
scoreboard players operation #zb_wd_fp mgs.data += #zb_to_spawn mgs.data
scoreboard players operation #zb_wd_fp mgs.data += #zb_portal_pending mgs.data

# Anything alive is progress: kiting is a normal state, and unreachable zombies are the stuck system's job.
scoreboard players set #zb_wd_moved mgs.data 0
execute if score #zb_alive mgs.data matches 1.. run scoreboard players set #zb_wd_moved mgs.data 1
execute unless score #zb_wd_fp mgs.data = #zb_wd_last mgs.data run scoreboard players set #zb_wd_moved mgs.data 1
scoreboard players operation #zb_wd_last mgs.data = #zb_wd_fp mgs.data

execute if score #zb_wd_moved mgs.data matches 1 run scoreboard players set #zb_wd_ticks mgs.data 0
execute if score #zb_wd_moved mgs.data matches 0 run scoreboard players add #zb_wd_ticks mgs.data 1

# 20 s, well past the 5 s handoff.
execute if score #zb_wd_ticks mgs.data matches 400.. run function mgs:zombies/recover

