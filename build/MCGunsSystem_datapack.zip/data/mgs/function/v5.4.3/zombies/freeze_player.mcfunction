
#> mgs:v5.4.3/zombies/freeze_player
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zombies/freeze_world [ as @a[scores={mgs.zb.in_game=1}] ]
#			mgs:v5.4.3/zombies/rejoin
#

attribute @s minecraft:movement_speed base set 0
attribute @s minecraft:jump_strength base set 0

