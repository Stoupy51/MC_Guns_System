
#> mgs:v5.4.3/zombies/zombie_rise_tick
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zombies/game_tick [ at @s ]
#

execute store result storage mgs:temp _rise.dy double 0.001 run scoreboard players get @s mgs.zb.rise_step
function mgs:v5.4.3/zombies/zombie_rise_move with storage mgs:temp _rise

scoreboard players remove @s mgs.zb.rise_tick 1
execute if score @s mgs.zb.rise_tick matches ..0 run function mgs:v5.4.3/zombies/zombie_finish_rise

