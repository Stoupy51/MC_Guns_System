
#> mgs:v5.4.3/shared/call_at_base
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/shared/maps/call_script_at_base with storage mgs:temp _base
#			mgs:v5.4.3/zombies/escort/setup_lure_center with storage mgs:temp _base
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			fn (unknown)
#

$execute positioned $(x) $(y) $(z) run function $(fn)

