
#> mgs:v5.4.3/shared/tp_to_position
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zombies/start with storage mgs:temp _tp [ as @a[scores={mgs.zb.in_game=1}] ]
#			mgs:v5.4.3/missions/start with storage mgs:temp _tp [ as @a[scores={mgs.mi.in_game=1}] ]
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#

$tp @s $(x) $(y) $(z)

