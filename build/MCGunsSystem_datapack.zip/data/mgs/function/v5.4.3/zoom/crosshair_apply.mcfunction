
#> mgs:v5.4.3/zoom/crosshair_apply
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zoom/crosshair_spread
#			mgs:v5.4.3/zoom/crosshair_base
#

# @s = any player, #spread = the level to show
execute unless score @s mgs.cross_to matches -2147483648.. run return run function mgs:v5.4.3/zoom/crosshair_first
execute if score @s mgs.cross_to = #spread mgs.data run return 0
function mgs:v5.4.3/zoom/crosshair_swap

