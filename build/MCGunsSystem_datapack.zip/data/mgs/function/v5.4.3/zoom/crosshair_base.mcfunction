
#> mgs:v5.4.3/zoom/crosshair_base
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/zoom/check_slowness
#

scoreboard players set #spread mgs.data 5
function mgs:v5.4.3/zoom/crosshair_apply

