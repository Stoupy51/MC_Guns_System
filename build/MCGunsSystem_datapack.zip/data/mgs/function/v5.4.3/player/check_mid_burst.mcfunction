
#> mgs:v5.4.3/player/check_mid_burst
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/player/set_pending_clicks
#

execute store result score #burst_limit mgs.data run data get storage mgs:gun all.stats.fire_modes[0].burst

execute if score @s mgs.burst_count < #burst_limit mgs.data run scoreboard players set #is_mid_burst mgs.data 1

