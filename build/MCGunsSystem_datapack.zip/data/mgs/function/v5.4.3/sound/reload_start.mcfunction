
#> mgs:v5.4.3/sound/reload_start
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/ammo/reload with storage mgs:gun all.sounds
#
# @args		reload (unknown)
#

$playsound mgs:$(reload) player @s

