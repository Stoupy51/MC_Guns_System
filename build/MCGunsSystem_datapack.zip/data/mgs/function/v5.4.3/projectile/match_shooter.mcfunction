
#> mgs:v5.4.3/projectile/match_shooter
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/projectile/explode [ as @a ]
#			mgs:v5.4.3/projectile/explode [ as @e[tag=mgs.armed] ]
#			mgs:v5.4.3/grenade/detonate_frag [ as @a ]
#			mgs:v5.4.3/grenade/detonate_frag [ as @e[tag=mgs.armed] ]
#

# `data modify ... set` succeeds only when the value changes, so 0 means the same UUID.
data modify storage mgs:temp copy_uuid set from entity @s UUID
execute store success score #is_match mgs.data run data modify storage mgs:temp copy_uuid set from storage mgs:temp expl.shooter_uuid

execute if score #is_match mgs.data matches 0 run scoreboard players set #found mgs.data 1
execute if score #is_match mgs.data matches 0 run tag @s add mgs.temp_shooter

