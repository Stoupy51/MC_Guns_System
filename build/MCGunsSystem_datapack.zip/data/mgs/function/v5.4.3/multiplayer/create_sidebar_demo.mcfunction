
#> mgs:v5.4.3/multiplayer/create_sidebar_demo
#
# @within	mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/multiplayer/start
#

function mgs:v5.4.3/multiplayer/refresh_sidebar_demo
scoreboard objectives setdisplay sidebar.team.red mgs.sidebar
scoreboard objectives setdisplay sidebar.team.blue mgs.sidebar
scoreboard objectives setdisplay sidebar.team.gold mgs.sidebar

