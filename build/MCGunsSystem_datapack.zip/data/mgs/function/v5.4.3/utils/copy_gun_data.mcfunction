
#> mgs:v5.4.3/utils/copy_gun_data
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.4.3/player/tick
#			mgs:v5.4.3/dialog/close_then
#			mgs:v5.4.3/player/set_pending_clicks
#			mgs:v5.4.3/player/swap_and_reload
#			mgs:v5.4.3/weapon/left_click
#			mgs:v5.4.3/switch/fire_mode_on_dropped_weapon
#			mgs:zombies/bonus/max_ammo
#			mgs:v5.4.3/zombies/wallbuys/on_right_click
#

data remove storage mgs:gun all
data modify storage mgs:gun SelectedItem set value {id:""}
execute unless items entity @s weapon.mainhand *[custom_data~{mgs:{}}] run return 0
item replace entity B5-0-0-0-3 contents from entity @s weapon.mainhand
data modify storage mgs:gun SelectedItem set from entity B5-0-0-0-3 item
data modify storage mgs:gun all set from storage mgs:gun SelectedItem.components."minecraft:custom_data".mgs

