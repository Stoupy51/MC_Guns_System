
#> mgs:v5.4.0/missions/end_prep
#
# @within	mgs:v5.4.0/dialog/close_then
#			mgs:v5.4.0/missions/preload_complete 180t [ scheduled ]
#

execute unless score #in_missions_map mgs.data matches 1 run return run function mgs:v5.4.0/shared/enter_map {mode:"missions",fn:"mgs:v5.4.0/missions/end_prep"}


execute unless data storage mgs:missions game{state:"preparing"} run return fail
data modify storage mgs:missions game.state set value "active"
execute as @a[scores={mgs.mi.in_game=1}] run attribute @s minecraft:movement_speed base reset
execute as @a[scores={mgs.mi.in_game=1}] run attribute @s minecraft:jump_strength base reset
effect clear @a[scores={mgs.mi.in_game=1}] darkness
effect clear @a[scores={mgs.mi.in_game=1}] blindness
effect clear @a[scores={mgs.mi.in_game=1}] night_vision

function mgs:v5.4.0/missions/spawn_all_enemies

# A mission with no enemies would complete at once (empty map or broken enemy functions).
execute if score #mi_total_enemies mgs.data matches ..0 run tellraw @a[scores={mgs.mi.in_game=1}] [[{"text":"","color":"gold"},"[",{"translate":"mgs","fallback":"MGS"},"] "],{"translate":"mgs.no_enemies_could_be_spawned_check_the_maps_enemy_markers_functio","fallback":"No enemies could be spawned. Check the map's enemy markers/functions in the editor.","color":"red"}]
execute if score #mi_total_enemies mgs.data matches ..0 run return run function mgs:v5.4.0/missions/stop

# After the enemies spawn.
execute if data storage mgs:missions game.map.start_commands[0] run function mgs:v5.4.0/shared/run_start_commands {mode:"missions"}

# The state is now active and chunks had time to load.
function mgs:v5.4.0/shared/maps/call_script_at_base {mode:"missions",script:"start"}

# Points to the nearest enemy.
execute as @a[scores={mgs.mi.in_game=1}] run item replace entity @s hotbar.3 with compass[custom_data={mgs:{compass:true}}]

# Counts up.
scoreboard players set #mi_timer mgs.data 0

tellraw @a[scores={mgs.mi.in_game=1}] ["",{"text":"","color":"aqua","bold":true},"🎯 ",{"translate":"mgs.go_go_go_kill_all_enemies","fallback":"GO! GO! GO! Kill all enemies!"}]

