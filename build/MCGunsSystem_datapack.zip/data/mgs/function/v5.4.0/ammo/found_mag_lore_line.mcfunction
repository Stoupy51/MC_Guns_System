
#> mgs:v5.4.0/ammo/found_mag_lore_line
#
# @within	mgs:v5.4.0/dialog/close_then
#			mgs:v5.4.0/ammo/search_mag_lore_loop with storage mgs:input with
#
# @args		slot (unknown)
#			index (unknown)
#			capacity (unknown)
#			remaining_bullets (unknown)
#

$item replace entity @s contents from entity @p[tag=mgs.modify_mag_lore] $(slot)

$data modify entity @s item.components."minecraft:lore"[$(index)].extra[-1] set value "$(capacity)"
$data modify entity @s item.components."minecraft:lore"[$(index)].extra[-3] set value "$(remaining_bullets)"

$item replace entity @p[tag=mgs.modify_mag_lore] $(slot) from entity @s contents

kill @s

