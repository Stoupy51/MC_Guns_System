
#> mgs:v5.4.0/zoom/fx_enter_zoom_pso
#
# @within	mgs:v5.4.0/dialog/close_then
#			mgs:v5.4.0/zoom/fx_enter
#

posteffect add @s mgs:zoom_pso
scoreboard players set @s mgs.zoom_fx 5
scoreboard players reset @s mgs.zoom_fx_off

