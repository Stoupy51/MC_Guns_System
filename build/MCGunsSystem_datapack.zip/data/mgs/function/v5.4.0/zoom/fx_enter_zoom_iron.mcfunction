
#> mgs:v5.4.0/zoom/fx_enter_zoom_iron
#
# @within	mgs:v5.4.0/dialog/close_then
#			mgs:v5.4.0/zoom/fx_enter
#

posteffect add @s mgs:zoom_iron
scoreboard players set @s mgs.zoom_fx 1
scoreboard players reset @s mgs.zoom_fx_off

