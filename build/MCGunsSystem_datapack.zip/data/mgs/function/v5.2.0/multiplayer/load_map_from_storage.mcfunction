
#> mgs:v5.2.0/multiplayer/load_map_from_storage
#
# @executed	as the player & at current position
#
# @within	mgs:v5.2.0/multiplayer/start with storage mgs:multiplayer game
#
# @args		map_id (unknown)
#

$function mgs:v5.2.0/shared/maps/load {id:"$(map_id)",mode:"multiplayer",override:{}}

