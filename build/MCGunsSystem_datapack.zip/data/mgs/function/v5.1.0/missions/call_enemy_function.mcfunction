
#> mgs:v5.1.0/missions/call_enemy_function
#
# @within	mgs:v5.1.0/missions/spawn_enemy_iter with storage mgs:temp _epos
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			function (unknown)
#

$execute positioned $(x) $(y) $(z) run function $(function)

## sourceMappingURL=call_enemy_function.mcfunction.map
