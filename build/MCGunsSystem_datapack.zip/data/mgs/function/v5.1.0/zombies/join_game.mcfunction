
#> mgs:v5.1.0/zombies/join_game
#
# @executed	as the player & at current position
#
# @within	mgs:v5.1.0/players/zb_join
#			dialog mgs:v5.1.0/zombies/setup
#

# Require an active game
execute unless data storage mgs:zombies game{state:"active"} run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.no_active_zombies_game_to_join","color":"red"}]

# Prevent double-joining
execute if score @s mgs.zb.in_game matches 1 run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.you_are_already_in_the_zombies_game","color":"red"}]

# Tag as in-game and reset stats
scoreboard players set @s mgs.zb.in_game 1
team join mgs.zombies @s
# Keep the XP spend tracker in step: an unsynced reset reads as points being SPENT (see zombies/xp.py)
scoreboard players set @s mgs.zb.points 500
scoreboard players set @s mgs.zb.xp_pts_prev 500
scoreboard players set @s mgs.zb.xp_spent_acc 0
scoreboard players set @s mgs.zb.kills 0
scoreboard players set @s mgs.zb.downs 0
scoreboard players set @s mgs.zb.passive 0
scoreboard players set @s mgs.zb.ability 0
scoreboard players set @s mgs.zb.ability_cd 0
scoreboard players set @s mgs.zb.horde_cd 0
scoreboard players set @s mgs.mp.spectate_timer 0
scoreboard players set @s mgs.mp.death_count 0
attribute @s minecraft:max_health base reset
attribute @s minecraft:entity_interaction_range base set 5

# Setup player
gamemode adventure @s

# Reset stamina so the stamina system re-inits this player at full (it owns the hunger bar)
scoreboard players set @s mgs.stam_seen 0

# Zombies has no class selection: give the fixed starting loadout (knife + pistol), matching the start function
function mgs:v5.1.0/zombies/inventory/give_starting_loadout

scoreboard players operation @s mgs.zb.prev_kills = @s mgs.total_kills

# Teleport to spawn
function mgs:v5.1.0/zombies/respawn_tp

# Call map join script (executed as the joining player)
function mgs:v5.1.0/shared/maps/call_script_at_base {script:"join"}

# Announce
tellraw @a ["",["",{"text":"[","color":"dark_gray"},{"score":{"name":"@s","objective":"mgs.zb.xp_level"},"color":"gold"},{"text":"] ","color":"dark_gray"},{"selector":"@s","color":"dark_green"}],[{"text":" ","color":"dark_green"}, {"translate":"mgs.joined_the_zombies_game"}]]

## sourceMappingURL=join_game.mcfunction.map
