
#> mgs:v5.1.0/zombies/setup
#
# @within	string in mgs:v5.1.0/players/list_zombies
#

function mgs:v5.1.0/dialogs/zombies/setup

