
#> mgs:v5.1.0/zombies/tp_player_at
#
# @executed	as @p[tag=mgs.spawn_pending]
#
# @within	mgs:v5.1.0/zombies/tp_to_spawn with storage mgs:temp _tp [ as @p[tag=mgs.spawn_pending] ]
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			yaw (unknown)
#

$tp @s $(x) $(y) $(z) $(yaw) 0

