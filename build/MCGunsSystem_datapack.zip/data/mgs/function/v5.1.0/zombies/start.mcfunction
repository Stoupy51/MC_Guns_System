
#> mgs:v5.1.0/zombies/start
#
# @executed	"","\ud83e\uddec ",{"translate":"mgs.variant"}],"tooltip":{"translate":"mgs.choose_the_zombies_experience"},"action":{"type":"run_command","command":"/function mgs:v5.1.0/dialogs/zombies/setup/variant"}},{"label":["","\u25b6 ",{"translate":"mgs.start","color":"green"}],"tooltip":{"translate":"mgs.start_the_zombies_game"},"action":{"type":"run_command","command":"/function mgs:v5.1.0/zombies/start"}},{"label":["","\u25a0 ",{"translate":"mgs.stop","color":"red"}],"tooltip":{"translate":"mgs.stop_the_zombies_game"},"action":{"type":"run_command","command":"/function mgs:v5.1.0/zombies/stop"}},{"label":["","\ud83d\udc65 ",{"translate":"mgs.manage_players","color":"dark_aqua"}],"tooltip":{"translate":"mgs.add_or_remove_players_from_the_zombies_game"},"action":{"type":"run_command","command":"/function mgs:v5.1.0/players/list_zombies"}},{"label":["","\ud83d\udc65 ",{"translate":"mgs.all_players_join","color":"green"}],"tooltip":{"translate":"mgs.add_every_online_player_to_the_zombies_game"},"action":{"type":"run_command","command":"/execute as @a run function mgs:v5.1.0/players/zb_join"}},{"label":["","+ ",{"translate":"mgs.join","color":"yellow"}],"tooltip":{"translate":"mgs.join_the_ongoing_zombies_game_as_a_late_joiner"},"action":{"type":"run_command","command":"/function mgs:v5.1.0/zombies/join_game"}}],"columns":2,"exit_action":{"label":["","\u25c0 ",{"translate":"mgs.back","color":"gray"}
#
# @within	mgs:v5.1.0/dialogs/zombies/setup {"label": ["", "\ud83e\uddec ", {"translate": "mgs.variant"}], "tooltip": {"translate": "mgs.choose_the_zombies_experience"}, "action": {"type": "run_command", "command": "/function mgs:v5.1.0/dialogs/zombies/setup/variant"}}, {"label": ["", "\u25b6 ", {"translate": "mgs.start", "color": "green"}], "tooltip": {"translate": "mgs.start_the_zombies_game"}, "action": {"type": "run_command", "command": "/function mgs:v5.1.0/zombies/start"}}, {"label": ["", "\u25a0 ", {"translate": "mgs.stop", "color": "red"}], "tooltip": {"translate": "mgs.stop_the_zombies_game"}, "action": {"type": "run_command", "command": "/function mgs:v5.1.0/zombies/stop"}}, {"label": ["", "\ud83d\udc65 ", {"translate": "mgs.manage_players", "color": "dark_aqua"}], "tooltip": {"translate": "mgs.add_or_remove_players_from_the_zombies_game"}, "action": {"type": "run_command", "command": "/function mgs:v5.1.0/players/list_zombies"}}, {"label": ["", "\ud83d\udc65 ", {"translate": "mgs.all_players_join", "color": "green"}], "tooltip": {"translate": "mgs.add_every_online_player_to_the_zombies_game"}, "action": {"type": "run_command", "command": "/execute as @a run function mgs:v5.1.0/players/zb_join"}}, {"label": ["", "+ ", {"translate": "mgs.join", "color": "yellow"}], "tooltip": {"translate": "mgs.join_the_ongoing_zombies_game_as_a_late_joiner"}, "action": {"type": "run_command", "command": "/function mgs:v5.1.0/zombies/join_game"}}], "columns": 2, "exit_action": {"label": ["", "\u25c0 ", {"translate": "mgs.back", "color": "gray"}], "tooltip": {"translate": "mgs.return_to_the_configuration_menu"}, "action": {"type": "run_command", "command": "/function mgs:v5.1.0/dialogs/config"}}}
#

# Prevent starting if already active or preparing
execute if data storage mgs:zombies game{state:"active"} run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.zombies_game_already_in_progress","color":"red"}]
execute if data storage mgs:zombies game{state:"preparing"} run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.zombies_game_already_preparing","color":"red"}]

# Require at least one opted-in player (players are independent until added via Manage Players / + Join)
execute unless entity @a[scores={mgs.zb.in_game=1}] run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.no_players_have_joined_the_zombies_game_use_manage_players_first","color":"red"}]

# Check that a map is selected
execute if data storage mgs:zombies game{map_id:""} run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.no_map_selected_use_the_setup_menu_to_select_a_map","color":"red"}]

# Load the selected map
function mgs:v5.1.0/zombies/load_map_from_storage with storage mgs:zombies game
execute unless score #map_load_found mgs.data matches 1 run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.map_not_found_select_a_valid_map","color":"red"}]

# Copy loaded map data into game state
data modify storage mgs:zombies game.map set from storage mgs:temp map_load.result

# Set state to preparing
data modify storage mgs:zombies game.state set value "preparing"

# Create zombies team
team add mgs.zombies
team modify mgs.zombies color yellow
team modify mgs.zombies friendlyFire false
team modify mgs.zombies nametagVisibility hideForOtherTeams

# Reset scores (in_game is left untouched: it's the opt-in flag, set via Manage Players / + Join)
scoreboard players set @a mgs.zb.points 500
scoreboard players set @a mgs.zb.kills 0
scoreboard players set @a mgs.zb.downs 0
scoreboard players set @a mgs.zb.passive 0
scoreboard players set @a mgs.zb.ability 0
scoreboard players set @a mgs.zb.ability_cd 0

# Config: points per kill, points per hit
scoreboard players set #zb_points_kill mgs.config 50
scoreboard players set #zb_points_hit mgs.config 5
scoreboard players set #zb_points_knife_kill mgs.config 130
scoreboard players set #zb_mystery_box_price mgs.config 950

# Assign opted-in players to the zombies team
team join mgs.zombies @a[scores={mgs.zb.in_game=1}]

# Initialize kill tracking baseline (so kills before game start don't count)
execute as @a run scoreboard players operation @s mgs.zb.prev_kills = @s mgs.total_kills

# Reset death counters and spectate timers to prevent false triggers
scoreboard players set @a mgs.mp.death_count 0
scoreboard players set @a mgs.mp.spectate_timer 0

# Clear other modes' in-game flags so their ticks/logic don't conflict with zombies
scoreboard players set @a mgs.mp.in_game 0
scoreboard players set @a mgs.mi.in_game 0

# Disable natural regeneration, enable custom regen system
# Disable natural regeneration, enable custom regen system
gamerule natural_health_regeneration false
scoreboard players set #any_game_active mgs.data 1

# Reset per-player regen state (hp_prev seeded from the auto-updated health criterion; a player
# whose criterion score is still unset just misses this seed and syncs on their first health change)
scoreboard players set @a mgs.last_hit 0
scoreboard players set @a mgs.hp_prev 0
execute as @a run scoreboard players operation @s mgs.hp_prev = @s mgs.health

# Reset stamina state so every player re-inits to full on their next stamina tick (also covers late-joiners)
scoreboard players set @a mgs.stam_seen 0

# Set gamerules
gamemode spectator @a[scores={mgs.zb.in_game=1}]
gamerule immediate_respawn true
gamerule keep_inventory true
gamerule max_entity_cramming 96
gamerule advance_time false
time set 18000

# Initialize round to 0 (first round will be 1)
data modify storage mgs:zombies game.round set value 0

# Store base coordinates for offset
function mgs:v5.1.0/shared/load_base_coordinates {mode:"zombies"}

# Check if map has boundaries defined
scoreboard players set #zb_has_bounds mgs.data 0
execute if data storage mgs:zombies game.map.boundaries[0] run scoreboard players set #zb_has_bounds mgs.data 1

# Normalize and store boundaries (only if defined)
execute if score #zb_has_bounds mgs.data matches 1 run function mgs:v5.1.0/shared/load_bounds {mode:"zombies"}

# Forceload the area (only if bounds defined)
execute if score #zb_has_bounds mgs.data matches 1 run function mgs:v5.1.0/shared/forceload_area

# Teleport all players as spectator to base coordinates for chunk preloading
execute store result storage mgs:temp _tp.x int 1 run scoreboard players get #gm_base_x mgs.data
execute store result storage mgs:temp _tp.y int 1 run scoreboard players get #gm_base_y mgs.data
execute store result storage mgs:temp _tp.z int 1 run scoreboard players get #gm_base_z mgs.data
execute as @a[scores={mgs.zb.in_game=1}] run function mgs:v5.1.0/shared/tp_to_position with storage mgs:temp _tp

# Register custom maps and mystery box items (extension points)
function #mgs:zombies/register_maps
function #mgs:zombies/register_mystery_box_item

# Schedule preload completion after 1 second
schedule function mgs:v5.1.0/zombies/preload_complete 20t

# Announce
tellraw @a ["",{"text":"","color":"dark_green","bold":true},"🧟 ",{"translate":"mgs.loading_zombies_map","color":"yellow"}]

# Escort system (escort.py)
scoreboard players set #zb_escort_count mgs.data 0
scoreboard players set #zb_lure mgs.data 0
gamerule spawn_wandering_traders false

# Initialize power state
scoreboard players set #zb_power mgs.data 0

# Initialize unlocked groups (group 0 = starting area, compound keys for quick lookup)
data modify storage mgs:zombies game.unlocked_groups set value {"0": 1b}

# Reset perk scoreboards for all known score holders (including offline players).
scoreboard players reset * mgs.zb.perk.juggernog
scoreboard players reset * mgs.zb.perk.speed_cola
scoreboard players reset * mgs.zb.perk.double_tap
scoreboard players reset * mgs.zb.perk.quick_revive
scoreboard players reset * mgs.zb.perk.mule_kick
scoreboard players reset * mgs.zb.perk.stamin_up

# Reset revive state
scoreboard players set @a mgs.zb.downed 0
scoreboard players set @a mgs.zb.bleed 0
scoreboard players set @a mgs.zb.revive_p 0
scoreboard players set @a mgs.zb.qr_uses 0
scoreboard players set @a mgs.zb.downed_id 0
scoreboard players set #downed_id_next mgs.data 0
tag @a remove mgs.downed_spectator
kill @e[tag=mgs.downed_mannequin]
kill @e[tag=mgs.downed_hud]
kill @e[tag=mgs.downed_cam]

