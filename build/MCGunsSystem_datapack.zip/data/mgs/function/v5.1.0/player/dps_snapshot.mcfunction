
#> mgs:v5.1.0/player/dps_snapshot
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.1.0/player/tick
#

scoreboard players operation @s mgs.previous_dps = @s mgs.dps
scoreboard players set @s mgs.dps 0
scoreboard players set @s mgs.dps_timer 0

