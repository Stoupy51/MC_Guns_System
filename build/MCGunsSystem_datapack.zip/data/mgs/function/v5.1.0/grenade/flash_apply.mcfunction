
#> mgs:v5.1.0/grenade/flash_apply
#
# @executed	at @s
#
# @within	mgs:v5.1.0/grenade/detonate_flash
#

execute store result storage mgs:temp flash.radius_float float 1 run data get entity @s data.config.grenade_effect_radius
function mgs:v5.1.0/grenade/flash_area with storage mgs:temp flash

