
#> mgs:v5.1.0/grenade/realistic_explosion
#
# @executed	at @s
#
# @within	mgs:v5.1.0/grenade/detonate_frag
#

scoreboard players operation #explosion_power realistic_explosion.data = #grenade_explosion_power mgs.config
execute if score #grenade_explosion_power mgs.config matches 1.. run scoreboard players set #falling_fire realistic_explosion.data 1
execute unless score #grenade_explosion_power mgs.config matches 1.. run scoreboard players set #falling_fire realistic_explosion.data 0
function realistic_explosion:explode

