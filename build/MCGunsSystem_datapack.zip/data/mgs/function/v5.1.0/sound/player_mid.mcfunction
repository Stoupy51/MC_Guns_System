
#> mgs:v5.1.0/sound/player_mid
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.1.0/sound/check/reload_mid with storage mgs:gun all.sounds
#
# @args		playermid (unknown)
#

$playsound mgs:$(playermid) player @a[distance=0.01..16] ~ ~ ~ 0.3

