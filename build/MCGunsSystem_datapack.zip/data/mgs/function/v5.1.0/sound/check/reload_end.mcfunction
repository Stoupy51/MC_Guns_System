
#> mgs:v5.1.0/sound/check/reload_end
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.1.0/player/tick
#

execute store result score #reload_end mgs.data run data get storage mgs:gun all.stats.reload_end
execute if score @s mgs.cooldown = #reload_end mgs.data run function mgs:v5.1.0/sound/player_end with storage mgs:gun all.sounds

