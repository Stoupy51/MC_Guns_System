
#> mgs:v5.1.0/kicks/type_0_ds
#
# @executed	as @e[type=player,sort=random] & at @s
#
# @within	mgs:v5.1.0/kicks/apply_ds
#

execute if score #has_vehicle mgs.data matches 0 if score #random mgs.data matches 1 run tp @s ~ ~ ~ ~-0.0325 ~-0.1625
execute if score #has_vehicle mgs.data matches 0 if score #random mgs.data matches 2 run tp @s ~ ~ ~ ~-0.0163 ~-0.1625
execute if score #has_vehicle mgs.data matches 0 if score #random mgs.data matches 3 run tp @s ~ ~ ~ ~-0.0 ~-0.1625
execute if score #has_vehicle mgs.data matches 0 if score #random mgs.data matches 4 run tp @s ~ ~ ~ ~0.0163 ~-0.1625
execute if score #has_vehicle mgs.data matches 0 if score #random mgs.data matches 5 run tp @s ~ ~ ~ ~0.0325 ~-0.1625
execute if score #has_vehicle mgs.data matches 1 if score #random mgs.data matches 1 run rotate @s ~-0.0325 ~-0.1625
execute if score #has_vehicle mgs.data matches 1 if score #random mgs.data matches 2 run rotate @s ~-0.0163 ~-0.1625
execute if score #has_vehicle mgs.data matches 1 if score #random mgs.data matches 3 run rotate @s ~-0.0 ~-0.1625
execute if score #has_vehicle mgs.data matches 1 if score #random mgs.data matches 4 run rotate @s ~0.0163 ~-0.1625
execute if score #has_vehicle mgs.data matches 1 if score #random mgs.data matches 5 run rotate @s ~0.0325 ~-0.1625

## sourceMappingURL=type_0_ds.mcfunction.map
