
#> mgs:v5.1.0/multiplayer/bounds_kill
#
# @executed	at @s
#
# @within	mgs:v5.1.0/multiplayer/check_bounds
#			mgs:v5.1.0/multiplayer/enforce_bounds
#

# No attacker: an environmental death.
data modify storage mgs:input with set value {}
function mgs:v5.1.0/multiplayer/simulate_death

