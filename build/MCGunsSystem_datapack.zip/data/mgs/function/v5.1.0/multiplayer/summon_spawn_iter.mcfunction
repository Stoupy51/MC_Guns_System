
#> mgs:v5.1.0/multiplayer/summon_spawn_iter
#
# @executed	as the player & at current position
#
# @within	mgs:v5.1.0/multiplayer/summon_spawns
#			mgs:v5.1.0/multiplayer/summon_spawn_iter
#

execute store result score #sx mgs.data run data get storage mgs:temp _spawn_iter[0][0]
execute store result score #sy mgs.data run data get storage mgs:temp _spawn_iter[0][1]
execute store result score #sz mgs.data run data get storage mgs:temp _spawn_iter[0][2]
execute store result score #syaw mgs.data run data get storage mgs:temp _spawn_iter[0][3] 100

scoreboard players operation #sx mgs.data += #gm_base_x mgs.data
scoreboard players operation #sy mgs.data += #gm_base_y mgs.data
scoreboard players operation #sz mgs.data += #gm_base_z mgs.data

execute store result storage mgs:temp _spos.x double 1 run scoreboard players get #sx mgs.data
execute store result storage mgs:temp _spos.y double 1 run scoreboard players get #sy mgs.data
execute store result storage mgs:temp _spos.z double 1 run scoreboard players get #sz mgs.data
execute store result storage mgs:temp _spos.yaw double 0.01 run scoreboard players get #syaw mgs.data
data modify storage mgs:temp _spos.tag set from storage mgs:temp _spawn_tag

function mgs:v5.1.0/multiplayer/summon_spawn_at with storage mgs:temp _spos

data remove storage mgs:temp _spawn_iter[0]
execute if data storage mgs:temp _spawn_iter[0] run function mgs:v5.1.0/multiplayer/summon_spawn_iter

