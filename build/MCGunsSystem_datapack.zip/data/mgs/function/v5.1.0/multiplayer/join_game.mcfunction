
#> mgs:v5.1.0/multiplayer/join_game
#
# @within	mgs:v5.1.0/players/mp_to_red
#			mgs:v5.1.0/players/mp_to_blue
#			dialog mgs:v5.1.0/multiplayer/setup
#

# Require an active game
execute unless data storage mgs:multiplayer game{state:"active"} unless data storage mgs:multiplayer game{state:"preparing"} run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.no_active_game_to_join","color":"red"}]

# Prevent double-joining
execute if score @s mgs.mp.in_game matches 1 run return run tellraw @s [[{"text":"","color":"gold"},"[",{"translate":"mgs"},"] "],{"translate":"mgs.you_are_already_in_the_game","color":"red"}]

# Tag as in-game and reset stats
scoreboard players set @s mgs.mp.in_game 1
scoreboard players set @s mgs.mp.kills 0
scoreboard players set @s mgs.mp.deaths 0
scoreboard players set @s mgs.mp.death_count 0
scoreboard players set @s mgs.mp.spectate_timer 0
scoreboard players set @s mgs.last_hit 0
execute store result score @s mgs.hp_prev run data get entity @s Health 1

# Assign to FFA team for ffa mode, otherwise auto-assign to team
execute if data storage mgs:multiplayer game{gamemode:"ffa"} run team join mgs.ffa @s
execute unless data storage mgs:multiplayer game{gamemode:"ffa"} unless score @s mgs.mp.team matches 1.. run function mgs:v5.1.0/multiplayer/auto_assign_team

# Setup player
gamemode adventure @s

attribute @s minecraft:waypoint_receive_range base set 0.0

# Reset stamina so the stamina system re-inits this player at full (it owns the hunger bar)
scoreboard players set @s mgs.stam_seen 0

# Enable class menu and show class selection
tag @s add mgs.give_class_menu
function mgs:v5.1.0/multiplayer/select_class

# Apply class if already chosen
execute unless score @s mgs.mp.class matches 0 run function mgs:v5.1.0/multiplayer/apply_class

# Teleport to spawn
function mgs:v5.1.0/multiplayer/respawn_tp

# Call map join script (executed as the joining player)
function mgs:v5.1.0/shared/maps/call_script_at_base {script:"join"}

# Announce
tellraw @a ["",["",{"text":"[","color":"dark_gray"},{"score":{"name":"@s","objective":"mgs.mp.xp_level"},"color":"gold"},{"text":"] ","color":"dark_gray"},{"selector":"@s","color":"yellow"}],[{"text":" ","color":"yellow"}, {"translate":"mgs.joined_the_game"}]]

## sourceMappingURL=join_game.mcfunction.map
