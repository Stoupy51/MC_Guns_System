
#> mgs:v5.1.0/mob/go_sleep
#
# @executed	as @e[tag=mgs.armed] & at @s
#
# @within	mgs:v5.1.0/mob/tick
#

tag @s add mgs.mob_sleeping
scoreboard players operation @s mgs.mob.timer = @s mgs.mob.sleep_time

