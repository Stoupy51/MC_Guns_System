
#> mgs:v5.1.0/shared/remove_forceload
#
# @executed	as the player & at current position
#
# @within	mgs:v5.1.0/zombies/stop
#			mgs:v5.1.0/missions/stop
#

execute store result storage mgs:temp _fl.x1 int 1 run scoreboard players get #bound_x1 mgs.data
execute store result storage mgs:temp _fl.z1 int 1 run scoreboard players get #bound_z1 mgs.data
execute store result storage mgs:temp _fl.x2 int 1 run scoreboard players get #bound_x2 mgs.data
execute store result storage mgs:temp _fl.z2 int 1 run scoreboard players get #bound_z2 mgs.data
function mgs:v5.1.0/shared/forceload_remove with storage mgs:temp _fl

## sourceMappingURL=remove_forceload.mcfunction.map
