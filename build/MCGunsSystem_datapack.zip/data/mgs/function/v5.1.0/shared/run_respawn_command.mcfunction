
#> mgs:v5.1.0/shared/run_respawn_command
#
# @executed	at @s
#
# @within	mgs:v5.1.0/shared/run_respawn_commands_iter with storage mgs:temp _respawn_cmd
#
# @args		command (unknown)
#

$execute at @s run $(command)

