
#> mgs:v5.1.0/shared/run_start_command
#
# @within	mgs:v5.1.0/shared/run_start_commands_iter with storage mgs:temp _start_cmd
#
# @args		x (unknown)
#			y (unknown)
#			z (unknown)
#			command (unknown)
#

$execute positioned $(x) $(y) $(z) run $(command)

## sourceMappingURL=run_start_command.mcfunction.map
