
#> mgs:v5.1.0/projectile/post_vel
#
# @executed	at @s
#
# @within	mgs:v5.1.0/projectile/tick [ at @s ]
#

# Collision: explode and stop.
execute if entity @s[tag=mgs.exploding] run return run function mgs:v5.1.0/projectile/explode

# Ray Gun: green swirl, Pack-a-Punched: red; others flame and smoke.
scoreboard players set #ray_gun mgs.data 0
execute if data entity @s data.config{base_weapon:"ray_gun"} run scoreboard players set #ray_gun mgs.data 1
execute if score #ray_gun mgs.data matches 1 if data entity @s data.config.pap_level run scoreboard players set #ray_gun mgs.data 2
execute if score #ray_gun mgs.data matches 2 run particle dust{color:[0.8,0.0,0.0],scale:1.5} ~ ~ ~ 0.1 0.1 0.1 0 8 force @a[distance=..128]
execute if score #ray_gun mgs.data matches 2 run particle crimson_spore ~ ~ ~ 0.1 0.1 0.1 0 3 force @a[distance=..128]
execute if score #ray_gun mgs.data matches 1 run particle dust{color:[0.0,0.8,0.0],scale:1.5} ~ ~ ~ 0.1 0.1 0.1 0 8 force @a[distance=..128]
execute if score #ray_gun mgs.data matches 1 run particle glow ~ ~ ~ 0.1 0.1 0.1 0 3 force @a[distance=..128]
execute if score #ray_gun mgs.data matches 0 run particle flame ~ ~ ~ 0.05 0.05 0.05 0.02 3 force @a[distance=..128]
execute if score #ray_gun mgs.data matches 0 run particle smoke ~ ~ ~ 0.1 0.1 0.1 0.01 2 force @a[distance=..128]

scoreboard players remove @s mgs.data 1

# Lifetime over: explode.
execute if score @s mgs.data matches ..0 run function mgs:v5.1.0/projectile/explode

