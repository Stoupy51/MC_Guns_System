
#> mgs:v5.1.0/players/append_self
#
# @executed	as @a
#
# @within	mgs:v5.1.0/players/list_multiplayer [ as @a ]
#			mgs:v5.1.0/players/list_zombies [ as @a ]
#			mgs:v5.1.0/players/list_missions [ as @a ]
#

data modify storage mgs:temp _plr_entry set value {color:"gray",name:"???"}
execute store result storage mgs:temp _plr_entry.id int 1 run scoreboard players get @s bs.id
execute if data storage mgs:temp {_plr_mode:"multiplayer"} if score @s mgs.mp.team matches 1 run data modify storage mgs:temp _plr_entry.color set value "red"
execute if data storage mgs:temp {_plr_mode:"multiplayer"} if score @s mgs.mp.team matches 2 run data modify storage mgs:temp _plr_entry.color set value "blue"
execute if data storage mgs:temp {_plr_mode:"zombies"} if score @s mgs.zb.in_game matches 1 run data modify storage mgs:temp _plr_entry.color set value "green"
execute if data storage mgs:temp {_plr_mode:"missions"} if score @s mgs.mi.in_game matches 1 run data modify storage mgs:temp _plr_entry.color set value "green"

# Dialog labels do not resolve selector components, so the name is baked in: an invisible probe's head gets @s's profile, and the name is read back.
execute at @s run summon armor_stand ~ ~ ~ {Tags:["mgs_name_probe"],Invisible:1b,NoGravity:1b}
loot replace entity @e[type=armor_stand,tag=mgs_name_probe,limit=1] armor.head loot mgs:get_username
data modify storage mgs:temp _plr_entry.name set from entity @e[type=armor_stand,tag=mgs_name_probe,limit=1] equipment.head.components."minecraft:profile".name
kill @e[type=armor_stand,tag=mgs_name_probe]

data modify storage mgs:temp _plr_iter append from storage mgs:temp _plr_entry

