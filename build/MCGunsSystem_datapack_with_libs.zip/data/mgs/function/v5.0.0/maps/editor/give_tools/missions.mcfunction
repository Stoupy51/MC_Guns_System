
#> mgs:v5.0.0/maps/editor/give_tools/missions
#
# @within	mgs:v5.0.0/maps/editor/give_tools
#

item replace entity @s hotbar.0 with minecraft:bat_spawn_egg[minecraft:item_name={"translate":"mgs.base_coordinates","color":"light_purple","italic":false},minecraft:item_model="minecraft:endermite_spawn_egg",minecraft:custom_data={mgs:{editor:true,type:"base_coordinates"}},minecraft:entity_data={id:"minecraft:bat",NoAI:1b,Silent:1b,Invulnerable:1b,Tags:["mgs.new_element","mgs.element.base_coordinates"]}]
item replace entity @s hotbar.1 with minecraft:bat_spawn_egg[minecraft:item_name={"translate":"mgs.mission_spawn","color":"aqua","italic":false},minecraft:item_model="minecraft:villager_spawn_egg",minecraft:custom_data={mgs:{editor:true,type:"mission_spawn"}},minecraft:entity_data={id:"minecraft:bat",NoAI:1b,Silent:1b,Invulnerable:1b,Tags:["mgs.new_element","mgs.element.mission_spawn"]}]
item replace entity @s hotbar.2 with minecraft:bat_spawn_egg[minecraft:item_name={"translate":"mgs.enemy","color":"red","italic":false},minecraft:item_model="minecraft:pillager_spawn_egg",minecraft:custom_data={mgs:{editor:true,type:"enemy"}},minecraft:entity_data={id:"minecraft:bat",NoAI:1b,Silent:1b,Invulnerable:1b,Tags:["mgs.new_element","mgs.element.enemy"]}]
item replace entity @s hotbar.3 with minecraft:bat_spawn_egg[minecraft:item_name={"translate":"mgs.out_of_bounds","color":"dark_red","italic":false},minecraft:item_model="minecraft:spider_spawn_egg",minecraft:custom_data={mgs:{editor:true,type:"out_of_bounds"}},minecraft:entity_data={id:"minecraft:bat",NoAI:1b,Silent:1b,Invulnerable:1b,Tags:["mgs.new_element","mgs.element.out_of_bounds"]}]
item replace entity @s hotbar.4 with minecraft:bat_spawn_egg[minecraft:item_name={"translate":"mgs.boundary_corner","color":"gray","italic":false},minecraft:item_model="minecraft:skeleton_spawn_egg",minecraft:custom_data={mgs:{editor:true,type:"boundary"}},minecraft:entity_data={id:"minecraft:bat",NoAI:1b,Silent:1b,Invulnerable:1b,Tags:["mgs.new_element","mgs.element.boundary"]}]
item replace entity @s hotbar.5 with minecraft:bat_spawn_egg[minecraft:item_name=[{"text":"⚙ ","color":"white","italic":false}, {"translate":"mgs.config"}],minecraft:item_model="minecraft:allay_spawn_egg",minecraft:custom_data={mgs:{editor:true,type:"config"}},minecraft:entity_data={id:"minecraft:bat",NoAI:1b,Silent:1b,Invulnerable:1b,Tags:["mgs.new_element","mgs.element.config"]}]

