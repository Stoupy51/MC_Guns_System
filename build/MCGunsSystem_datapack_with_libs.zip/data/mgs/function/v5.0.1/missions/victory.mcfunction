
#> mgs:v5.0.1/missions/victory
#
# @within	mgs:v5.0.1/missions/game_tick
#

# Compute per-player mission kills from totalKillCount delta
execute as @a[scores={mgs.mi.in_game=1}] run scoreboard players operation @s mgs.mi.kills = @s mgs.mi.kill_total
execute as @a[scores={mgs.mi.in_game=1}] run scoreboard players operation @s mgs.mi.kills -= @s mgs.mi.kill_base

# Calculate time in seconds
scoreboard players operation #mi_seconds mgs.data = #mi_timer mgs.data
scoreboard players operation #mi_seconds mgs.data /= #20 mgs.data

# Calculate minutes and remaining seconds
scoreboard players operation #mi_minutes mgs.data = #mi_seconds mgs.data
scoreboard players operation #mi_minutes mgs.data /= #60 mgs.data
scoreboard players operation #mi_rem_sec mgs.data = #mi_seconds mgs.data
scoreboard players operation #mi_rem_sec mgs.data %= #60 mgs.data

# Title
title @a[scores={mgs.mi.in_game=1}] times 10 80 20
title @a[scores={mgs.mi.in_game=1}] title {"translate":"mgs.mission_complete","color":"gold","bold":true}
title @a[scores={mgs.mi.in_game=1}] subtitle {"translate":"mgs.all_enemies_eliminated","color":"green"}

# Performance summary
tellraw @a ["","\n",[{"text":"═══════ ","color":"gold","bold":true}, {"translate":"mgs.mission_complete"}, " ═══════"]]
tellraw @a ["","  ",[{"text":"⏱ ","color":"gray"}, {"translate":"mgs.time"}],{"score":{"name":"#mi_minutes","objective":"mgs.data"},"color":"yellow"},"m ",{"score":{"name":"#mi_rem_sec","objective":"mgs.data"},"color":"yellow"},"s"]
tellraw @a ["","  ",[{"text":"💀 ","color":"gray"}, {"translate":"mgs.enemies_killed"}],{"score":{"name":"#mi_total_enemies","objective":"mgs.data"},"color":"red"}]

# Per-player stats
execute as @a[scores={mgs.mi.in_game=1}] run tellraw @a ["","  ",{"text":"🎖 ","color":"gray"},{"selector":"@s","color":"yellow"}," — Kills: ",{"score":{"name":"@s","objective":"mgs.mi.kills"},"color":"green"}," | Deaths: ",{"score":{"name":"@s","objective":"mgs.mi.deaths"},"color":"red"}]

tellraw @a ["",{"text":"═══════════════════════════════","color":"gold","bold":true},"\n"]

# End game
function mgs:v5.0.1/missions/stop

