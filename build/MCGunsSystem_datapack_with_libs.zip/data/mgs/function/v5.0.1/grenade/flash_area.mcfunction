
#> mgs:v5.0.1/grenade/flash_area
#
# @executed	as @e[tag=mgs.grenade] & at @s
#
# @within	mgs:v5.0.1/grenade/flash_apply with storage mgs:temp flash
#
# @args		radius_float (unknown)
#

$execute as @a[distance=..$(radius_float)] at @s run function mgs:v5.0.1/grenade/flash_check

