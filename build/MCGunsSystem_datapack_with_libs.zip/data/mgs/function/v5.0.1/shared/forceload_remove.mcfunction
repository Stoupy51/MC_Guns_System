
#> mgs:v5.0.1/shared/forceload_remove
#
# @within	mgs:v5.0.1/shared/remove_forceload with storage mgs:temp _fl
#
# @args		x1 (unknown)
#			z1 (unknown)
#			x2 (unknown)
#			z2 (unknown)
#

$forceload remove $(x1) $(z1) $(x2) $(z2)

