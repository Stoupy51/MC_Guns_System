
#> mgs:v5.0.1/casing/process_vectors
#
# @executed	anchored eyes & positioned ^ ^ ^
#
# @within	mgs:v5.0.1/casing/main [ anchored eyes & positioned ^ ^ ^ ]
#

# 1. Calculate base vectors
function mgs:v5.0.1/casing/calculate_vectors

# 2. Calculate motion based on these vectors
function mgs:v5.0.1/casing/calculate_motion

# 3. Calculate position offset based on these vectors
function mgs:v5.0.1/casing/calculate_offset

# 4. Kill marker
kill @s

